import { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
  Box,
  Drawer,
  AppBar,
  Toolbar,
  List,
  Typography,
  Divider,
  IconButton,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Avatar,
  Menu,
  MenuItem,
  Badge,
  Breadcrumbs,
  Link,
  Chip,
  useMediaQuery,
  useTheme,
  SwipeableDrawer,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Dashboard,
  Inventory2,
  ShoppingCart,
  LocalShipping,
  PendingActions,
  CalendarMonth,
  Settings,
  Notifications,
  Logout,
  Person,
  ChevronLeft,
  Business,
} from '@mui/icons-material';
import { useAuthStore } from '../../store/authStore';
import useApprovalStore from '../../store/approvalStore';

const drawerWidth = 260;
const miniDrawerWidth = 64;

const menuItems = [
  { text: 'ダッシュボード', icon: <Dashboard />, path: '/' },
  { text: '在庫管理', icon: <Inventory2 />, path: '/inventory' },
  { text: '発注管理', icon: <ShoppingCart />, path: '/purchases' },
  { text: '販売管理', icon: <LocalShipping />, path: '/sales' },
  { text: '承認管理', icon: <PendingActions />, path: '/approvals' },
  { text: 'カレンダー', icon: <CalendarMonth />, path: '/calendar' },
  { text: '設定', icon: <Settings />, path: '/settings' },
];

const MainLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));
  
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const approvals = useApprovalStore((state) => state.approvals);

  const pendingApprovals = approvals.filter((a) => a.status === 'pending').length;

  const [drawerOpen, setDrawerOpen] = useState(!isMobile);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleDrawerToggle = () => {
    if (isMobile) {
      setMobileOpen(!mobileOpen);
    } else {
      setDrawerOpen(!drawerOpen);
    }
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    handleMenuClose();
    logout();
    navigate('/login');
  };

  const handleNavigate = (path: string) => {
    navigate(path);
    if (isMobile) {
      setMobileOpen(false);
    }
  };

  const getBreadcrumbs = () => {
    const pathnames = location.pathname.split('/').filter((x) => x);
    const breadcrumbMap: Record<string, string> = {
      inventory: '在庫管理',
      purchases: '発注管理',
      sales: '販売管理',
      approvals: '承認管理',
      calendar: 'カレンダー',
      settings: '設定',
      new: '新規作成',
    };

    if (isMobile && pathnames.length > 0) {
      return (
        <Typography color="white" fontWeight="medium" fontSize={14}>
          {breadcrumbMap[pathnames[0]] || pathnames[0]}
        </Typography>
      );
    }

    return (
      <Breadcrumbs sx={{ color: 'white' }}>
        <Link
          underline="hover"
          color="inherit"
          onClick={() => navigate('/')}
          sx={{ cursor: 'pointer', fontSize: { xs: 12, sm: 14 } }}
        >
          ホーム
        </Link>
        {pathnames.map((value, index) => {
          const last = index === pathnames.length - 1;
          const to = `/${pathnames.slice(0, index + 1).join('/')}`;
          const label = breadcrumbMap[value] || value;

          return last ? (
            <Typography color="white" key={to} fontWeight="medium" fontSize={{ xs: 12, sm: 14 }}>
              {label}
            </Typography>
          ) : (
            <Link
              underline="hover"
              color="inherit"
              onClick={() => navigate(to)}
              key={to}
              sx={{ cursor: 'pointer', fontSize: { xs: 12, sm: 14 } }}
            >
              {label}
            </Link>
          );
        })}
      </Breadcrumbs>
    );
  };

  const drawerContent = (
    <>
      <Toolbar
        sx={{
          bgcolor: 'primary.main',
          borderRadius: 0,
          display: 'flex',
          justifyContent: 'center',
          py: 2,
          minHeight: { xs: 56, sm: 64 },
        }}
      >
        {drawerOpen || isMobile ? (
          <Typography
            variant={isMobile ? 'h6' : 'h5'}
            fontWeight="bold"
            color="white"
            sx={{ letterSpacing: 2 }}
          >
            SmartStock
          </Typography>
        ) : (
          <Typography variant="h6" fontWeight="bold" color="white">
            SS
          </Typography>
        )}
      </Toolbar>

      {/* ユーザー情報（モバイル時） */}
      {isMobile && user && (
        <Box sx={{ p: 2, bgcolor: 'grey.50' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Avatar sx={{ bgcolor: 'primary.main' }}>
              {user.name?.charAt(0) || 'U'}
            </Avatar>
            <Box>
              <Typography fontWeight="medium" fontSize={14}>
                {user.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {user.accountType === 'personal' ? '個人' : user.companyName}
              </Typography>
            </Box>
          </Box>
        </Box>
      )}

      <List sx={{ pt: 2 }}>
        {menuItems.map((item) => {
          const isActive = location.pathname === item.path ||
            (item.path !== '/' && location.pathname.startsWith(item.path));

          return (
            <ListItem key={item.text} disablePadding sx={{ px: 1, mb: 0.5 }}>
              <ListItemButton
                onClick={() => handleNavigate(item.path)}
                sx={{
                  borderRadius: 2,
                  bgcolor: isActive ? 'primary.light' : 'transparent',
                  color: isActive ? 'primary.main' : 'text.primary',
                  minHeight: 48,
                  justifyContent: drawerOpen || isMobile ? 'initial' : 'center',
                  px: 2.5,
                  transition: 'background-color 0.2s',
                  '&:hover': {
                    bgcolor: isActive ? 'primary.light' : 'action.hover',
                  },
                }}
              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: drawerOpen || isMobile ? 2 : 'auto',
                    justifyContent: 'center',
                    color: isActive ? 'primary.main' : 'text.secondary',
                  }}
                >
                  {item.text === '承認管理' ? (
                    <Badge badgeContent={pendingApprovals} color="error">
                      {item.icon}
                    </Badge>
                  ) : (
                    item.icon
                  )}
                </ListItemIcon>
                {(drawerOpen || isMobile) && (
                  <ListItemText
                    primary={item.text}
                    primaryTypographyProps={{
                      fontWeight: isActive ? 600 : 400,
                      fontSize: 14,
                    }}
                  />
                )}
              </ListItemButton>
            </ListItem>
          );
        })}
      </List>

      {/* ログアウト（モバイル時） */}
      {isMobile && (
        <>
          <Divider sx={{ mt: 'auto' }} />
          <ListItem disablePadding sx={{ p: 1 }}>
            <ListItemButton onClick={handleLogout} sx={{ borderRadius: 2 }}>
              <ListItemIcon sx={{ minWidth: 40 }}>
                <Logout color="error" />
              </ListItemIcon>
              <ListItemText primary="ログアウト" primaryTypographyProps={{ color: 'error' }} />
            </ListItemButton>
          </ListItem>
        </>
      )}
    </>
  );

  const actualDrawerWidth = drawerOpen ? drawerWidth : miniDrawerWidth;

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
      {/* AppBar */}
      <AppBar
        position="fixed"
        sx={{
          width: { md: `calc(100% - ${actualDrawerWidth}px)` },
          ml: { md: `${actualDrawerWidth}px` },
          transition: 'width 0.3s, margin-left 0.3s',
          bgcolor: 'primary.main',
          boxShadow: 3,
          borderRadius: 0,
        }}
      >
        <Toolbar sx={{ minHeight: { xs: 56, sm: 64 }, borderRadius: 0 }}>
          <IconButton
            color="inherit"
            onClick={handleDrawerToggle}
            edge="start"
            sx={{ mr: 2 }}
          >
            {isMobile ? <MenuIcon /> : drawerOpen ? <ChevronLeft /> : <MenuIcon />}
          </IconButton>

          {getBreadcrumbs()}

          <Box sx={{ flexGrow: 1 }} />

          <IconButton
            color="inherit"
            sx={{ mr: { xs: 0.5, sm: 1 } }}
            onClick={() => navigate('/approvals')}
          >
            <Badge badgeContent={pendingApprovals} color="error">
              <Notifications />
            </Badge>
          </IconButton>

          {!isMobile && (
            <IconButton onClick={handleMenuClick}>
              <Avatar
                sx={{
                  bgcolor: 'white',
                  color: 'primary.main',
                  width: 36,
                  height: 36,
                }}
              >
                {user?.name?.charAt(0) || 'U'}
              </Avatar>
            </IconButton>
          )}

          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
          >
            <MenuItem disabled>
              <Person sx={{ mr: 1 }} />
              {user?.name}
            </MenuItem>
            {user?.companyName && (
              <MenuItem disabled>
                <Business sx={{ mr: 1 }} />
                {user.companyName}
              </MenuItem>
            )}
            <Divider />
            <MenuItem onClick={() => { handleMenuClose(); navigate('/settings'); }}>
              <Settings sx={{ mr: 1 }} />
              設定
            </MenuItem>
            <MenuItem onClick={handleLogout}>
              <Logout sx={{ mr: 1 }} />
              ログアウト
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      {/* モバイル用ドロワー */}
      {isMobile ? (
        <SwipeableDrawer
          anchor="left"
          open={mobileOpen}
          onClose={() => setMobileOpen(false)}
          onOpen={() => setMobileOpen(true)}
          sx={{
            '& .MuiDrawer-paper': {
              width: drawerWidth,
              boxSizing: 'border-box',
            borderRadius: 0,
            },
          }}
        >
          {drawerContent}
        </SwipeableDrawer>
      ) : (
        /* デスクトップ用ドロワー */
        <Drawer
          variant="permanent"
          sx={{
            width: actualDrawerWidth,
            flexShrink: 0,
            transition: 'width 0.3s',
            '& .MuiDrawer-paper': {
              width: actualDrawerWidth,
              boxSizing: 'border-box',
              transition: 'width 0.3s',
              overflowX: 'hidden',
              borderRight: 'none',
              boxShadow: '2px 0 8px rgba(0,0,0,0.1)',
              borderRadius: 0,
            },
          }}
        >
          {drawerContent}
        </Drawer>
      )}

      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: { xs: 2, sm: 3 },
          mt: { xs: 7, sm: 8 },
          ml: 0,
          transition: 'margin-left 0.3s',
          display: 'flex',
          justifyContent: 'center',
          width: '100%',
          overflowX: 'hidden',
        }}
      >
        <Box sx={{ width: '100%', maxWidth: 1600 }}>
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
};

export default MainLayout;
