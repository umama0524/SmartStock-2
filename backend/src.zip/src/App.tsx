import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import theme from './theme';
import CssBaseline from '@mui/material/CssBaseline';

// Store
import { useAuthStore } from './store/authStore';

// Layout
import MainLayout from './components/layout/MainLayout';

// Pages
import LoginPage from './pages/auth/LoginPage';
import DashboardPage from './pages/dashboard/DashboardPage';
import InventoryListPage from './pages/inventory/InventoryListPage';
import InventoryDetailPage from './pages/inventory/InventoryDetailPage';
import PurchaseListPage from './pages/purchases/PurchaseListPage';
import PurchaseDetailPage from './pages/purchases/PurchaseDetailPage';
import PurchaseCreatePage from './pages/purchases/PurchaseCreatePage';
import SalesListPage from './pages/sales/SalesListPage';
import SalesDetailPage from './pages/sales/SalesDetailPage';
import SalesCreatePage from './pages/sales/SalesCreatePage';
import ApprovalListPage from './pages/approvals/ApprovalListPage';
import CalendarPage from './pages/calendar/CalendarPage';
import SettingsPage from './pages/settings/SettingsPage';

// Use the centrally defined MUI theme from src/theme.ts. This theme
// defines a blue‑centric palette with semantic colours for success,
// warning and error states, and glassmorphism styling for buttons.
// Centralising the theme ensures consistent styling across the
// application and makes it easy to adjust colours in one place.

// Private Route
const PrivateRoute = ({ children }: { children: React.ReactNode }) => {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
};

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <Routes>
          {/* 認証 */}
          <Route path="/login" element={<LoginPage />} />

          {/* メインアプリ（認証必須） */}
          <Route
            path="/"
            element={
              <PrivateRoute>
                <MainLayout />
              </PrivateRoute>
            }
          >
            <Route index element={<DashboardPage />} />

            {/* 在庫管理 */}
            <Route path="inventory" element={<InventoryListPage />} />
            <Route path="inventory/:id" element={<InventoryDetailPage />} />

            {/* 発注管理 */}
            <Route path="purchases" element={<PurchaseListPage />} />
            <Route path="purchases/new" element={<PurchaseCreatePage />} />
            <Route path="purchases/:id" element={<PurchaseDetailPage />} />

            {/* 販売管理 */}
            <Route path="sales" element={<SalesListPage />} />
            <Route path="sales/new" element={<SalesCreatePage />} />
            <Route path="sales/:id" element={<SalesDetailPage />} />

            {/* 承認管理 */}
            <Route path="approvals" element={<ApprovalListPage />} />

            {/* カレンダー */}
            <Route path="calendar" element={<CalendarPage />} />

            {/* 設定 */}
            <Route path="settings" element={<SettingsPage />} />
          </Route>

          {/* 404 */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;
