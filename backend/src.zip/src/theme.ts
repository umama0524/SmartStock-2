import { createTheme } from '@mui/material/styles';

// Custom MUI theme defining a professional colour palette and component overrides.
// This theme centralises the colour scheme and basic component styling so that
// the application maintains a cohesive look and feel. Colours are aligned to
// conventional semantic meanings (primary for actions, success for positive
// states, error for destructive actions, warning for cautions and info for
// informational accents). The background and text colours are neutral to
// ensure high readability. Buttons and cards are given consistent rounding
// and elevation behaviours to improve tactility.
const theme = createTheme({
  palette: {
    // Use a softer, more legible blue for the primary colour.  This
    // improves contrast and reduces the harshness of the previous
    // purple‑tinted palette.  The light shade is very subtle so the
    // navigation highlights and cards feel airy, while the dark shade
    // provides sufficient contrast for icons and text.  Secondary
    // colours have been neutralised to a cool grey to avoid
    // competing with the primary accent.
    mode: 'light',
    primary: {
      main: '#3B82F6',      // Tailwind blue‑500 – a calm, professional blue
      light: '#EFF6FF',     // Very light blue for backgrounds and highlights
      dark: '#1E40AF',      // Deep indigo for strong accents
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: '#64748B',      // Cool grey for secondary actions and text
      light: '#F8FAFC',     // Near‑white for subtle surfaces
      dark: '#334155',      // Dark grey for contrast against light surfaces
      contrastText: '#FFFFFF',
    },
    error: {
      main: '#E53E3E',
      light: '#FDEDED',
      dark: '#9B1C1C',
      contrastText: '#FFFFFF',
    },
    warning: {
      main: '#F59E0B',
      light: '#FFF7ED',
      dark: '#B45309',
      contrastText: '#FFFFFF',
    },
    success: {
      main: '#16A34A',
      light: '#ECFDF5',
      dark: '#166534',
      contrastText: '#FFFFFF',
    },
    info: {
      main: '#0EA5E9',
      light: '#E0F2FE',
      dark: '#0369A1',
      contrastText: '#FFFFFF',
    },
    background: {
      default: '#F9FAFB',   // Light neutral background
      paper: '#FFFFFF',     // Card background
    },
    text: {
      primary: '#111827',   // Dark grey for high readability
      secondary: '#6B7280', // Muted grey for secondary text
    },
  },
  shape: {
    borderRadius: 8,
  },
  components: {
    // Override the default MUI button styling to create a
    // translucent “bubble” effect.  All buttons share the same
    // glass‑like appearance with a subtle backdrop blur and
    // semi‑transparent border.  Colour is removed from the
    // background so that the emphasis remains on the content and
    // surrounding cards.  A gentle hover state deepens the
    // translucency for tactile feedback without introducing new
    // colours.  Buttons retain rounded corners for a softer look.
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 20,
          textTransform: 'none',
          padding: '10px 24px',
          // Liquid glass styling: a multi‑layered gradient with frosted background
          background: 'linear-gradient(135deg, rgba(255,255,255,0.55) 0%, rgba(255,255,255,0.25) 100%)',
          backdropFilter: 'blur(20px)',
          border: '1px solid rgba(255,255,255,0.5)',
          color: '#0f172a', // dark slate for readability
          boxShadow:
            'inset 2px 2px 4px rgba(255,255,255,0.4), inset -2px -2px 4px rgba(0,0,0,0.1), 0 8px 16px rgba(0,0,0,0.08)',
          transition:
            'background 0.3s ease, box-shadow 0.3s ease, border-color 0.3s ease',
          '&:hover': {
            background: 'linear-gradient(135deg, rgba(255,255,255,0.65) 0%, rgba(255,255,255,0.35) 100%)',
            borderColor: 'rgba(255,255,255,0.6)',
            boxShadow:
              'inset 2px 2px 4px rgba(255,255,255,0.5), inset -2px -2px 4px rgba(0,0,0,0.15), 0 12px 20px rgba(0,0,0,0.1)',
          },
        },
      },
      defaultProps: {
        disableElevation: true,
        variant: 'contained',
      },
    },
    // Card styling remains consistent with the previous version.  Cards
    // have gentle elevation and raise slightly on hover for
    // interactiveness.  Rounded corners match the new button radius.
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
          transition: 'transform 0.2s, box-shadow 0.2s',
          '&:hover': {
            boxShadow: '0 4px 16px rgba(0,0,0,0.08)',
            transform: 'translateY(-2px)',
          },
        },
      },
    },
  },
});

export default theme;