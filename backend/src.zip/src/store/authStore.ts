import { create } from 'zustand';

export type UserRole = 'viewer' | 'inventory' | 'purchase' | 'sales' | 'approver' | 'admin';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  isAdmin?: boolean;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  isAuthenticated: false,

  login: (user) => {
    set({
      user,
      token: `token-${Date.now()}`,
      isAuthenticated: true,
    });
  },

  logout: () => {
    set({
      user: null,
      token: null,
      isAuthenticated: false,
    });
  },
}));

export default useAuthStore;