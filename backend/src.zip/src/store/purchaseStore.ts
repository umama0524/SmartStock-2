import { create } from 'zustand';

export type POStatus = 'draft' | 'pending' | 'approved' | 'partial' | 'completed' | 'cancelled';

export interface PurchaseOrderItem {
  id: string;
  productId: string;
  sku: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  receivedQuantity?: number;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierId: string;
  supplierName: string;
  orderDate: string;
  expectedDeliveryDate: string;
  actualDeliveryDate?: string;
  status: POStatus;
  totalAmount: number;
  taxAmount: number;
  grandTotal: number;
  paymentTerms: string;
  note?: string;
  items: PurchaseOrderItem[];
  requesterId: string;
  requesterName: string;
  approverId?: string;
  approverName?: string;
  approvedAt?: string;
  approverComment?: string;
  cancelReason?: string;
}

interface PurchaseState {
  orders: PurchaseOrder[];
  
  // アクション
  addOrder: (order: Omit<PurchaseOrder, 'id' | 'poNumber'>) => string;
  updateStatus: (id: string, status: POStatus, comment?: string, approverName?: string) => void;
  receiveItems: (id: string, receivedItems: Record<string, number>) => void;
  cancelOrder: (id: string, reason: string) => void;
  getById: (id: string) => PurchaseOrder | undefined;
  getPendingApprovals: () => PurchaseOrder[];
  getNextPoNumber: () => string;
}

// 初期データ
const initialOrders: PurchaseOrder[] = [
  {
    id: '1',
    poNumber: 'PO-2025-001',
    supplierId: '1',
    supplierName: 'オフィス用品株式会社',
    orderDate: '2025-01-10',
    expectedDeliveryDate: '2025-01-20',
    actualDeliveryDate: '2025-01-19',
    status: 'completed',
    totalAmount: 125000,
    taxAmount: 12500,
    grandTotal: 137500,
    paymentTerms: '月末締め翌月末払い',
    items: [
      { id: '1', productId: '1', sku: 'SKU-001', productName: 'A4用紙（500枚）', quantity: 100, unitPrice: 250, subtotal: 25000, receivedQuantity: 100 },
      { id: '2', productId: '2', sku: 'SKU-045', productName: 'ボールペン（黒）', quantity: 500, unitPrice: 80, subtotal: 40000, receivedQuantity: 500 },
      { id: '3', productId: '3', sku: 'SKU-089', productName: 'クリアファイル', quantity: 500, unitPrice: 120, subtotal: 60000, receivedQuantity: 500 },
    ],
    requesterId: '3',
    requesterName: '発注 花子',
    approverId: '1',
    approverName: '管理者',
    approvedAt: '2025-01-11 10:00',
  },
  {
    id: '2',
    poNumber: 'PO-2025-002',
    supplierId: '2',
    supplierName: '文具センター',
    orderDate: '2025-01-12',
    expectedDeliveryDate: '2025-01-25',
    status: 'pending',
    totalAmount: 89000,
    taxAmount: 8900,
    grandTotal: 97900,
    paymentTerms: '前払い',
    items: [
      { id: '1', productId: '4', sku: 'SKU-123', productName: 'ノート（B5）', quantity: 200, unitPrice: 180, subtotal: 36000 },
      { id: '2', productId: '5', sku: 'SKU-156', productName: 'ホッチキス', quantity: 50, unitPrice: 450, subtotal: 22500 },
      { id: '3', productId: '6', sku: 'SKU-201', productName: '付箋紙セット', quantity: 100, unitPrice: 210, subtotal: 21000 },
    ],
    requesterId: '3',
    requesterName: '発注 花子',
    note: '急ぎでお願いします',
  },
  {
    id: '3',
    poNumber: 'PO-2025-003',
    supplierId: '1',
    supplierName: 'オフィス用品株式会社',
    orderDate: '2025-01-14',
    expectedDeliveryDate: '2025-01-28',
    status: 'approved',
    totalAmount: 64000,
    taxAmount: 6400,
    grandTotal: 70400,
    paymentTerms: '月末締め翌月末払い',
    items: [
      { id: '1', productId: '7', sku: 'SKU-234', productName: 'マーカーペン（蛍光5色）', quantity: 200, unitPrice: 320, subtotal: 64000 },
    ],
    requesterId: '3',
    requesterName: '発注 花子',
    approverId: '1',
    approverName: '管理者',
    approvedAt: '2025-01-15 09:00',
  },
  {
    id: '4',
    poNumber: 'PO-2025-004',
    supplierId: '3',
    supplierName: '事務機器販売',
    orderDate: '2025-01-15',
    expectedDeliveryDate: '2025-01-30',
    status: 'draft',
    totalAmount: 45000,
    taxAmount: 4500,
    grandTotal: 49500,
    paymentTerms: '月末締め翌月末払い',
    items: [
      { id: '1', productId: '8', sku: 'SKU-267', productName: 'カッターナイフ', quantity: 300, unitPrice: 150, subtotal: 45000 },
    ],
    requesterId: '3',
    requesterName: '発注 花子',
  },
];

let orderCounter = 5;

export const usePurchaseStore = create<PurchaseState>((set, get) => ({
  orders: initialOrders,

  addOrder: (orderData) => {
    const id = String(orderCounter++);
    const poNumber = get().getNextPoNumber();
    const newOrder: PurchaseOrder = {
      ...orderData,
      id,
      poNumber,
    };
    set((state) => ({
      orders: [...state.orders, newOrder],
    }));
    return id;
  },

  updateStatus: (id, status, comment, approverName) => {
    const now = new Date().toLocaleString('ja-JP');
    set((state) => ({
      orders: state.orders.map((order) => {
        if (order.id === id) {
          return {
            ...order,
            status,
            approverComment: comment || order.approverComment,
            approverName: approverName || order.approverName,
            approvedAt: status === 'approved' ? now : order.approvedAt,
          };
        }
        return order;
      }),
    }));
  },

  receiveItems: (id, receivedItems) => {
    const now = new Date().toISOString().split('T')[0];
    set((state) => ({
      orders: state.orders.map((order) => {
        if (order.id === id) {
          const updatedItems = order.items.map((item) => ({
            ...item,
            receivedQuantity: (item.receivedQuantity || 0) + (receivedItems[item.id] || 0),
          }));
          
          const allReceived = updatedItems.every(
            (item) => (item.receivedQuantity || 0) >= item.quantity
          );
          const someReceived = updatedItems.some(
            (item) => (item.receivedQuantity || 0) > 0
          );

          return {
            ...order,
            items: updatedItems,
            status: allReceived ? 'completed' : someReceived ? 'partial' : order.status,
            actualDeliveryDate: allReceived ? now : order.actualDeliveryDate,
          };
        }
        return order;
      }),
    }));
  },

  cancelOrder: (id, reason) => {
    set((state) => ({
      orders: state.orders.map((order) => {
        if (order.id === id) {
          return {
            ...order,
            status: 'cancelled',
            cancelReason: reason,
          };
        }
        return order;
      }),
    }));
  },

  getById: (id) => {
    return get().orders.find((order) => order.id === id);
  },

  getPendingApprovals: () => {
    return get().orders.filter((order) => order.status === 'pending');
  },

  getNextPoNumber: () => {
    const year = new Date().getFullYear();
    const existing = get().orders.filter((o) => o.poNumber.startsWith(`PO-${year}`));
    const maxNum = existing.reduce((max, o) => {
      const num = parseInt(o.poNumber.split('-')[2], 10);
      return num > max ? num : max;
    }, 0);
    return `PO-${year}-${String(maxNum + 1).padStart(3, '0')}`;
  },
}));

export default usePurchaseStore;
