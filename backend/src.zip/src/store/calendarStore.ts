import { create } from 'zustand';

export interface CalendarEvent {
  id: string;
  date: string;
  title: string;
  description: string;
  type: 'instruction' | 'delivery' | 'shipment' | 'other';
  createdBy: string;
  createdAt: string;
}

interface CalendarState {
  events: CalendarEvent[];
  addEvent: (event: Omit<CalendarEvent, 'id' | 'createdAt'>) => void;
  updateEvent: (id: string, event: Partial<CalendarEvent>) => void;
  deleteEvent: (id: string) => void;
}

const today = new Date().toISOString().split('T')[0];
const twoDaysLater = new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0];

const initialEvents: CalendarEvent[] = [
  {
    id: 'ev-1',
    date: today,
    title: '月次在庫棚卸',
    description: '全商品の在庫数を確認してください',
    type: 'instruction',
    createdBy: '管理者',
    createdAt: '2025-01-10 09:00',
  },
  {
    id: 'ev-2',
    date: twoDaysLater,
    title: '大口発注入荷予定',
    description: 'オフィス用品株式会社からの入荷',
    type: 'delivery',
    createdBy: '管理者',
    createdAt: '2025-01-12 10:00',
  },
];

let eventCounter = 10;

const useCalendarStore = create<CalendarState>((set) => ({
  events: initialEvents,

  addEvent: (eventData) => {
    const id = `ev-${eventCounter++}`;
    const newEvent: CalendarEvent = {
      ...eventData,
      id,
      createdAt: new Date().toLocaleString('ja-JP'),
    };
    set((state) => ({
      events: [...state.events, newEvent],
    }));
  },

  updateEvent: (id, eventData) => {
    set((state) => ({
      events: state.events.map((event) =>
        event.id === id ? { ...event, ...eventData } : event
      ),
    }));
  },

  deleteEvent: (id) => {
    set((state) => ({
      events: state.events.filter((event) => event.id !== id),
    }));
  },
}));

export default useCalendarStore;
