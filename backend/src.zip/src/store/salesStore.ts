import { create } from 'zustand';

export type SOStatus = 'draft' | 'confirmed' | 'reserved' | 'picked' | 'shipped' | 'delivered' | 'cancelled';

export interface SalesOrderItem {
  id: string;
  productId: string;
  sku: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  shippedQuantity?: number;
  location?: string;
}

export interface SalesOrder {
  id: string;
  soNumber: string;
  customerId: string;
  customerName: string;
  orderDate: string;
  deliveryDate: string;
  actualDeliveryDate?: string;
  status: SOStatus;
  shippingAddress: string;
  totalAmount: number;
  taxAmount: number;
  grandTotal: number;
  note?: string;
  items: SalesOrderItem[];
  salesRepId: string;
  salesRepName: string;
  trackingNumber?: string;
  cancelReason?: string;
}

interface SalesState {
  orders: SalesOrder[];
  
  // アクション
  addOrder: (order: Omit<SalesOrder, 'id' | 'soNumber'>) => string;
  updateStatus: (id: string, status: SOStatus) => void;
  shipOrder: (id: string, trackingNumber?: string) => void;
  deliverOrder: (id: string) => void;
  cancelOrder: (id: string, reason: string) => void;
  getById: (id: string) => SalesOrder | undefined;
  getNextSoNumber: () => string;
}

// 初期データ
const initialOrders: SalesOrder[] = [
  {
    id: '1',
    soNumber: 'SO-2025-001',
    customerId: '1',
    customerName: '株式会社ABCコーポレーション',
    orderDate: '2025-01-08',
    deliveryDate: '2025-01-15',
    actualDeliveryDate: '2025-01-15',
    status: 'delivered',
    shippingAddress: '〒100-0001 東京都千代田区千代田1-1-1 ABCビル5F',
    totalAmount: 98000,
    taxAmount: 9800,
    grandTotal: 107800,
    items: [
      { id: '1', productId: '1', sku: 'SKU-001', productName: 'A4用紙（500枚）', quantity: 200, unitPrice: 250, subtotal: 50000, shippedQuantity: 200, location: '倉庫A-01' },
      { id: '2', productId: '2', sku: 'SKU-045', productName: 'ボールペン（黒）', quantity: 600, unitPrice: 80, subtotal: 48000, shippedQuantity: 600, location: '倉庫A-02' },
    ],
    salesRepId: '4',
    salesRepName: '販売 花子',
    trackingNumber: 'TRACK-001',
  },
  {
    id: '2',
    soNumber: 'SO-2025-002',
    customerId: '2',
    customerName: '有限会社XYZ商事',
    orderDate: '2025-01-12',
    deliveryDate: '2025-01-18',
    status: 'shipped',
    shippingAddress: '〒105-0001 東京都港区虎ノ門2-2-2 XYZビル3F',
    totalAmount: 156000,
    taxAmount: 15600,
    grandTotal: 171600,
    items: [
      { id: '1', productId: '3', sku: 'SKU-089', productName: 'クリアファイル', quantity: 300, unitPrice: 120, subtotal: 36000, shippedQuantity: 300, location: '倉庫B-12' },
      { id: '2', productId: '6', sku: 'SKU-201', productName: '付箋紙セット', quantity: 400, unitPrice: 210, subtotal: 84000, shippedQuantity: 400, location: '倉庫B-08' },
      { id: '3', productId: '4', sku: 'SKU-123', productName: 'ノート（B5）', quantity: 200, unitPrice: 180, subtotal: 36000, shippedQuantity: 200, location: '倉庫A-05' },
    ],
    salesRepId: '4',
    salesRepName: '販売 花子',
    trackingNumber: 'TRACK-002',
  },
  {
    id: '3',
    soNumber: 'SO-2025-003',
    customerId: '3',
    customerName: '株式会社DEFエンタープライズ',
    orderDate: '2025-01-14',
    deliveryDate: '2025-01-20',
    status: 'picked',
    shippingAddress: '〒150-0043 東京都渋谷区道玄坂3-3-3 DEFタワー10F',
    totalAmount: 89600,
    taxAmount: 8960,
    grandTotal: 98560,
    items: [
      { id: '1', productId: '7', sku: 'SKU-234', productName: 'マーカーペン（蛍光5色）', quantity: 100, unitPrice: 320, subtotal: 32000, location: '倉庫A-03' },
      { id: '2', productId: '5', sku: 'SKU-156', productName: 'ホッチキス', quantity: 80, unitPrice: 450, subtotal: 36000, location: '倉庫C-03' },
      { id: '3', productId: '8', sku: 'SKU-267', productName: 'カッターナイフ', quantity: 144, unitPrice: 150, subtotal: 21600, location: '倉庫C-05' },
    ],
    salesRepId: '4',
    salesRepName: '販売 花子',
    note: '午前中配送希望',
  },
  {
    id: '4',
    soNumber: 'SO-2025-004',
    customerId: '1',
    customerName: '株式会社ABCコーポレーション',
    orderDate: '2025-01-15',
    deliveryDate: '2025-01-22',
    status: 'reserved',
    shippingAddress: '〒100-0001 東京都千代田区千代田1-1-1 ABCビル5F',
    totalAmount: 52500,
    taxAmount: 5250,
    grandTotal: 57750,
    items: [
      { id: '1', productId: '1', sku: 'SKU-001', productName: 'A4用紙（500枚）', quantity: 50, unitPrice: 250, subtotal: 12500, location: '倉庫A-01' },
      { id: '2', productId: '2', sku: 'SKU-045', productName: 'ボールペン（黒）', quantity: 500, unitPrice: 80, subtotal: 40000, location: '倉庫A-02' },
    ],
    salesRepId: '4',
    salesRepName: '販売 花子',
  },
  {
    id: '5',
    soNumber: 'SO-2025-005',
    customerId: '2',
    customerName: '有限会社XYZ商事',
    orderDate: '2025-01-15',
    deliveryDate: '2025-01-25',
    status: 'confirmed',
    shippingAddress: '〒105-0001 東京都港区虎ノ門2-2-2 XYZビル3F',
    totalAmount: 72000,
    taxAmount: 7200,
    grandTotal: 79200,
    items: [
      { id: '1', productId: '3', sku: 'SKU-089', productName: 'クリアファイル', quantity: 600, unitPrice: 120, subtotal: 72000, location: '倉庫B-12' },
    ],
    salesRepId: '4',
    salesRepName: '販売 花子',
  },
];

let orderCounter = 6;

export const useSalesStore = create<SalesState>((set, get) => ({
  orders: initialOrders,

  addOrder: (orderData) => {
    const id = String(orderCounter++);
    const soNumber = get().getNextSoNumber();
    const newOrder: SalesOrder = {
      ...orderData,
      id,
      soNumber,
    };
    set((state) => ({
      orders: [...state.orders, newOrder],
    }));
    return id;
  },

  updateStatus: (id, status) => {
    set((state) => ({
      orders: state.orders.map((order) => {
        if (order.id === id) {
          return { ...order, status };
        }
        return order;
      }),
    }));
  },

  shipOrder: (id, trackingNumber) => {
    set((state) => ({
      orders: state.orders.map((order) => {
        if (order.id === id) {
          const updatedItems = order.items.map((item) => ({
            ...item,
            shippedQuantity: item.quantity,
          }));
          return {
            ...order,
            status: 'shipped' as SOStatus,
            items: updatedItems,
            trackingNumber: trackingNumber || order.trackingNumber,
          };
        }
        return order;
      }),
    }));
  },

  deliverOrder: (id) => {
    const now = new Date().toISOString().split('T')[0];
    set((state) => ({
      orders: state.orders.map((order) => {
        if (order.id === id) {
          return {
            ...order,
            status: 'delivered' as SOStatus,
            actualDeliveryDate: now,
          };
        }
        return order;
      }),
    }));
  },

  cancelOrder: (id, reason) => {
    set((state) => ({
      orders: state.orders.map((order) => {
        if (order.id === id) {
          return {
            ...order,
            status: 'cancelled' as SOStatus,
            cancelReason: reason,
          };
        }
        return order;
      }),
    }));
  },

  getById: (id) => {
    return get().orders.find((order) => order.id === id);
  },

  getNextSoNumber: () => {
    const year = new Date().getFullYear();
    const existing = get().orders.filter((o) => o.soNumber.startsWith(`SO-${year}`));
    const maxNum = existing.reduce((max, o) => {
      const num = parseInt(o.soNumber.split('-')[2], 10);
      return num > max ? num : max;
    }, 0);
    return `SO-${year}-${String(maxNum + 1).padStart(3, '0')}`;
  },
}));

export default useSalesStore;
