import { create } from 'zustand';

export type InventoryStatus = 'normal' | 'low' | 'critical' | 'excess';

export interface InventoryItem {
  id: string;
  sku: string;
  productName: string;
  quantity: number;
  reservedQuantity: number;
  availableQuantity: number;
  reorderPoint: number;
  safetyStock: number;
  status: InventoryStatus;
  location: string;
  unitPrice: number;
  lastUpdated: string;
}

export interface InventoryTransaction {
  id: string;
  date: string;
  type: '入庫' | '出庫' | '調整' | '棚卸';
  quantity: number;
  balance: number;
  reason: string;
  user: string;
  lotNumber?: string;
  note?: string;
}

interface InventoryState {
  inventory: InventoryItem[];
  transactions: Record<string, InventoryTransaction[]>;
  
  // アクション
  inbound: (id: string, quantity: number, lotNumber: string, note: string, user: string) => void;
  outbound: (id: string, quantity: number, reason: string, note: string, user: string) => void;
  adjust: (id: string, adjustmentQuantity: number, reasonCode: string, note: string, user: string) => void;
  getById: (id: string) => InventoryItem | undefined;
  getTransactions: (id: string) => InventoryTransaction[];
}

// ステータスを計算する関数
const calculateStatus = (quantity: number, safetyStock: number, reorderPoint: number): InventoryStatus => {
  if (quantity <= safetyStock) return 'critical';
  if (quantity <= reorderPoint) return 'low';
  return 'normal';
};

// 初期データ
const initialInventory: InventoryItem[] = [
  { id: '1', sku: 'SKU-001', productName: 'A4用紙（500枚）', quantity: 45, reservedQuantity: 10, availableQuantity: 35, reorderPoint: 100, safetyStock: 50, status: 'critical', location: '倉庫A-01', unitPrice: 250, lastUpdated: '2025-01-15 09:30' },
  { id: '2', sku: 'SKU-045', productName: 'ボールペン（黒）', quantity: 120, reservedQuantity: 20, availableQuantity: 100, reorderPoint: 150, safetyStock: 80, status: 'low', location: '倉庫A-02', unitPrice: 80, lastUpdated: '2025-01-15 10:15' },
  { id: '3', sku: 'SKU-089', productName: 'クリアファイル', quantity: 580, reservedQuantity: 50, availableQuantity: 530, reorderPoint: 200, safetyStock: 100, status: 'normal', location: '倉庫B-12', unitPrice: 120, lastUpdated: '2025-01-14 16:45' },
  { id: '4', sku: 'SKU-123', productName: 'ノート（B5）', quantity: 340, reservedQuantity: 40, availableQuantity: 300, reorderPoint: 150, safetyStock: 80, status: 'normal', location: '倉庫A-05', unitPrice: 180, lastUpdated: '2025-01-15 08:00' },
  { id: '5', sku: 'SKU-156', productName: 'ホッチキス', quantity: 25, reservedQuantity: 5, availableQuantity: 20, reorderPoint: 50, safetyStock: 30, status: 'critical', location: '倉庫C-03', unitPrice: 450, lastUpdated: '2025-01-13 14:20' },
  { id: '6', sku: 'SKU-201', productName: '付箋紙セット', quantity: 890, reservedQuantity: 90, availableQuantity: 800, reorderPoint: 300, safetyStock: 150, status: 'normal', location: '倉庫B-08', unitPrice: 210, lastUpdated: '2025-01-15 11:30' },
  { id: '7', sku: 'SKU-234', productName: 'マーカーペン（蛍光5色）', quantity: 200, reservedQuantity: 20, availableQuantity: 180, reorderPoint: 100, safetyStock: 50, status: 'normal', location: '倉庫A-03', unitPrice: 320, lastUpdated: '2025-01-14 09:00' },
  { id: '8', sku: 'SKU-267', productName: 'カッターナイフ', quantity: 100, reservedQuantity: 10, availableQuantity: 90, reorderPoint: 80, safetyStock: 40, status: 'normal', location: '倉庫C-05', unitPrice: 150, lastUpdated: '2025-01-12 15:45' },
];

// 初期取引履歴
const initialTransactions: Record<string, InventoryTransaction[]> = {
  '1': [
    { id: 't1', date: '2025-01-15 09:30', type: '出庫', quantity: -50, balance: 45, reason: '販売出荷', user: '山田太郎' },
    { id: 't2', date: '2025-01-14 14:00', type: '入庫', quantity: 100, balance: 95, reason: '定期発注分入荷', user: '鈴木花子', lotNumber: 'LOT-2025-0114' },
    { id: 't3', date: '2025-01-10 10:00', type: '調整', quantity: -5, balance: -5, reason: '棚卸差異', user: '佐藤一郎' },
  ],
};

export const useInventoryStore = create<InventoryState>((set, get) => ({
  inventory: initialInventory,
  transactions: initialTransactions,

  inbound: (id, quantity, lotNumber, note, user) => {
    const now = new Date().toLocaleString('ja-JP');
    set((state) => {
      const inventory = state.inventory.map((item) => {
        if (item.id === id) {
          const newQuantity = item.quantity + quantity;
          const newAvailable = newQuantity - item.reservedQuantity;
          return {
            ...item,
            quantity: newQuantity,
            availableQuantity: newAvailable,
            status: calculateStatus(newQuantity, item.safetyStock, item.reorderPoint),
            lastUpdated: now,
          };
        }
        return item;
      });

      const updatedItem = inventory.find(i => i.id === id);
      const newTransaction: InventoryTransaction = {
        id: `t-${Date.now()}`,
        date: now,
        type: '入庫',
        quantity: quantity,
        balance: updatedItem?.quantity || 0,
        reason: '入庫登録',
        user,
        lotNumber,
        note,
      };

      const existingTransactions = state.transactions[id] || [];
      return {
        inventory,
        transactions: {
          ...state.transactions,
          [id]: [newTransaction, ...existingTransactions],
        },
      };
    });
  },

  outbound: (id, quantity, reason, note, user) => {
    const now = new Date().toLocaleString('ja-JP');
    set((state) => {
      const inventory = state.inventory.map((item) => {
        if (item.id === id) {
          const newQuantity = item.quantity - quantity;
          const newAvailable = newQuantity - item.reservedQuantity;
          return {
            ...item,
            quantity: newQuantity,
            availableQuantity: newAvailable,
            status: calculateStatus(newQuantity, item.safetyStock, item.reorderPoint),
            lastUpdated: now,
          };
        }
        return item;
      });

      const updatedItem = inventory.find(i => i.id === id);
      const newTransaction: InventoryTransaction = {
        id: `t-${Date.now()}`,
        date: now,
        type: '出庫',
        quantity: -quantity,
        balance: updatedItem?.quantity || 0,
        reason,
        user,
        note,
      };

      const existingTransactions = state.transactions[id] || [];
      return {
        inventory,
        transactions: {
          ...state.transactions,
          [id]: [newTransaction, ...existingTransactions],
        },
      };
    });
  },

  adjust: (id, adjustmentQuantity, reasonCode, note, user) => {
    const now = new Date().toLocaleString('ja-JP');
    const reasonMap: Record<string, string> = {
      damaged: '破損',
      expired: '期限切れ',
      lost: '紛失',
      found: '発見',
      count_diff: '棚卸差異',
      other: 'その他',
    };

    set((state) => {
      const inventory = state.inventory.map((item) => {
        if (item.id === id) {
          const newQuantity = item.quantity + adjustmentQuantity;
          const newAvailable = newQuantity - item.reservedQuantity;
          return {
            ...item,
            quantity: newQuantity,
            availableQuantity: newAvailable,
            status: calculateStatus(newQuantity, item.safetyStock, item.reorderPoint),
            lastUpdated: now,
          };
        }
        return item;
      });

      const updatedItem = inventory.find(i => i.id === id);
      const newTransaction: InventoryTransaction = {
        id: `t-${Date.now()}`,
        date: now,
        type: '調整',
        quantity: adjustmentQuantity,
        balance: updatedItem?.quantity || 0,
        reason: reasonMap[reasonCode] || 'その他',
        user,
        note,
      };

      const existingTransactions = state.transactions[id] || [];
      return {
        inventory,
        transactions: {
          ...state.transactions,
          [id]: [newTransaction, ...existingTransactions],
        },
      };
    });
  },

  getById: (id) => {
    return get().inventory.find((item) => item.id === id);
  },

  getTransactions: (id) => {
    return get().transactions[id] || [];
  },
}));

export default useInventoryStore;
