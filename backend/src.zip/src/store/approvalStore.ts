import { create } from 'zustand';

export type ApprovalStatus = 'pending' | 'approved' | 'rejected';
export type ApprovalType = 'purchase' | 'adjustment';

export interface ApprovalRequest {
  id: string;
  type: ApprovalType;
  referenceId: string;
  referenceNumber: string;
  title: string;
  requesterId: string;
  requesterName: string;
  requestDate: string;
  status: ApprovalStatus;
  amount?: number;
  itemCount?: number;
  reason?: string;
  note?: string;
  approverName?: string;
  approvedDate?: string;
  approverComment?: string;
}

interface ApprovalState {
  approvals: ApprovalRequest[];
  
  // アクション
  addApproval: (approval: Omit<ApprovalRequest, 'id'>) => string;
  approve: (id: string, approverName: string, comment?: string) => void;
  reject: (id: string, approverName: string, comment: string) => void;
  getPendingByType: (type: ApprovalType) => ApprovalRequest[];
  getHistory: () => ApprovalRequest[];
  getById: (id: string) => ApprovalRequest | undefined;
}

// 初期データ
const initialApprovals: ApprovalRequest[] = [
  {
    id: 'apr-1',
    type: 'purchase',
    referenceId: '2',
    referenceNumber: 'PO-2025-002',
    title: '文具センターへの発注',
    requesterId: '3',
    requesterName: '発注 花子',
    requestDate: '2025-01-12',
    status: 'pending',
    amount: 97900,
    itemCount: 3,
    note: '急ぎでお願いします',
  },
  {
    id: 'apr-2',
    type: 'adjustment',
    referenceId: 'adj-1',
    referenceNumber: 'ADJ-2025-001',
    title: 'A4用紙の在庫調整',
    requesterId: '2',
    requesterName: '在庫 太郎',
    requestDate: '2025-01-14',
    status: 'pending',
    reason: '棚卸差異',
    note: '実棚との差異 -15個',
  },
  {
    id: 'apr-3',
    type: 'purchase',
    referenceId: '6',
    referenceNumber: 'PO-2025-006',
    title: '事務機器販売への発注',
    requesterId: '3',
    requesterName: '発注 花子',
    requestDate: '2025-01-15',
    status: 'pending',
    amount: 156000,
    itemCount: 5,
  },
  {
    id: 'apr-4',
    type: 'adjustment',
    referenceId: 'adj-2',
    referenceNumber: 'ADJ-2025-002',
    title: 'ボールペン在庫調整',
    requesterId: '2',
    requesterName: '在庫 太郎',
    requestDate: '2025-01-15',
    status: 'pending',
    reason: '破損',
    note: '輸送中の破損 -20個',
  },
  {
    id: 'apr-5',
    type: 'purchase',
    referenceId: '7',
    referenceNumber: 'PO-2025-007',
    title: 'オフィス用品株式会社への発注',
    requesterId: '3',
    requesterName: '発注 花子',
    requestDate: '2025-01-15',
    status: 'pending',
    amount: 89000,
    itemCount: 2,
  },
  // 履歴（承認済み・却下）
  {
    id: 'apr-h1',
    type: 'purchase',
    referenceId: '1',
    referenceNumber: 'PO-2025-001',
    title: 'オフィス用品株式会社への発注',
    requesterId: '3',
    requesterName: '発注 花子',
    requestDate: '2025-01-10',
    status: 'approved',
    amount: 137500,
    itemCount: 3,
    approverName: '管理者',
    approvedDate: '2025-01-11',
    approverComment: '承認します',
  },
  {
    id: 'apr-h2',
    type: 'adjustment',
    referenceId: 'adj-0',
    referenceNumber: 'ADJ-2025-000',
    title: 'クリアファイル在庫調整',
    requesterId: '2',
    requesterName: '在庫 太郎',
    requestDate: '2025-01-08',
    status: 'rejected',
    reason: 'その他',
    note: '理由不明の差異',
    approverName: '管理者',
    approvedDate: '2025-01-09',
    approverComment: '理由の詳細を再確認してください',
  },
];

let approvalCounter = 10;

export const useApprovalStore = create<ApprovalState>((set, get) => ({
  approvals: initialApprovals,

  addApproval: (approvalData) => {
    const id = `apr-${approvalCounter++}`;
    const newApproval: ApprovalRequest = {
      ...approvalData,
      id,
    };
    set((state) => ({
      approvals: [...state.approvals, newApproval],
    }));
    return id;
  },

  approve: (id, approverName, comment) => {
    const now = new Date().toISOString().split('T')[0];
    set((state) => ({
      approvals: state.approvals.map((approval) => {
        if (approval.id === id) {
          return {
            ...approval,
            status: 'approved' as ApprovalStatus,
            approverName,
            approvedDate: now,
            approverComment: comment,
          };
        }
        return approval;
      }),
    }));
  },

  reject: (id, approverName, comment) => {
    const now = new Date().toISOString().split('T')[0];
    set((state) => ({
      approvals: state.approvals.map((approval) => {
        if (approval.id === id) {
          return {
            ...approval,
            status: 'rejected' as ApprovalStatus,
            approverName,
            approvedDate: now,
            approverComment: comment,
          };
        }
        return approval;
      }),
    }));
  },

  getPendingByType: (type) => {
    return get().approvals.filter(
      (approval) => approval.type === type && approval.status === 'pending'
    );
  },

  getHistory: () => {
    return get().approvals.filter(
      (approval) => approval.status === 'approved' || approval.status === 'rejected'
    );
  },

  getById: (id) => {
    return get().approvals.find((approval) => approval.id === id);
  },
}));

export default useApprovalStore;
