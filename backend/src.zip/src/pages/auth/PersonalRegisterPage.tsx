import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Alert,
  Link,
  Stepper,
  Step,
  StepLabel,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import { ArrowBack, PersonAdd, CheckCircle } from '@mui/icons-material';
import useUserStore from '../../store/userStore';

const steps = ['基本情報', '連絡先', '確認'];

const PersonalRegisterPage = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const addUser = useUserStore((state) => state.addUser);
  const users = useUserStore((state) => state.users);

  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    loginId: '',
    password: '',
    confirmPassword: '',
    name: '',
    email: '',
    phone: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [field]: e.target.value });
    setError('');
  };

  const validateStep = () => {
    switch (activeStep) {
      case 0:
        if (!formData.loginId.trim()) {
          setError('ログインIDを入力してください');
          return false;
        }
        if (formData.loginId.length < 4) {
          setError('ログインIDは4文字以上で入力してください');
          return false;
        }
        // 重複チェック
        const duplicate = users.find(
          (u) => u.accountType === 'personal' && u.loginId === formData.loginId
        );
        if (duplicate) {
          setError('このログインIDは既に使用されています');
          return false;
        }
        if (!formData.password) {
          setError('パスワードを入力してください');
          return false;
        }
        if (formData.password.length < 6) {
          setError('パスワードは6文字以上で入力してください');
          return false;
        }
        if (formData.password !== formData.confirmPassword) {
          setError('パスワードが一致しません');
          return false;
        }
        if (!formData.name.trim()) {
          setError('名前を入力してください');
          return false;
        }
        break;
      case 1:
        if (!formData.email.trim()) {
          setError('メールアドレスを入力してください');
          return false;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
          setError('正しいメールアドレスを入力してください');
          return false;
        }
        if (!formData.phone.trim()) {
          setError('電話番号を入力してください');
          return false;
        }
        break;
    }
    return true;
  };

  const handleNext = () => {
    if (!validateStep()) return;

    if (activeStep === steps.length - 1) {
      // 登録処理
      addUser({
        accountType: 'personal',
        loginId: formData.loginId,
        password: formData.password,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
      });
      setSuccess(true);
    } else {
      setActiveStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
    setError('');
  };

  if (success) {
    return (
      <Box
        sx={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          bgcolor: 'primary.light',
          p: 2,
        }}
      >
        <Paper sx={{ p: 4, textAlign: 'center', maxWidth: 400, borderRadius: 3 }}>
          <CheckCircle sx={{ fontSize: 64, color: 'success.main', mb: 2 }} />
          <Typography variant="h5" fontWeight="bold" gutterBottom>
            登録完了！
          </Typography>
          <Typography color="text.secondary" sx={{ mb: 3 }}>
            アカウントが正常に作成されました。
            <br />
            ログインIDでログインしてください。
          </Typography>
          <Typography variant="body2" sx={{ mb: 3, bgcolor: 'grey.100', p: 2, borderRadius: 2 }}>
            ログインID: <strong>{formData.loginId}</strong>
          </Typography>
          <Button
            variant="contained"
            fullWidth
            onClick={() => navigate('/login')}
            sx={{
              bgcolor: 'primary.main',
              color: 'primary.contrastText',
              '&:hover': {
                bgcolor: 'primary.dark',
              },
            }}
          >
            ログインページへ
          </Button>
        </Paper>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        bgcolor: 'primary.light',
        p: 2,
      }}
    >
      <Paper sx={{ p: { xs: 3, sm: 4 }, width: '100%', maxWidth: 500, borderRadius: 3 }}>
        {/* ヘッダー */}
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <Button
            startIcon={<ArrowBack />}
            onClick={() => navigate('/login')}
            sx={{ mr: 2 }}
          >
            戻る
          </Button>
          <Typography variant={isMobile ? 'h6' : 'h5'} fontWeight="bold">
            個人アカウント登録
          </Typography>
        </Box>

        {/* ステッパー */}
        <Stepper activeStep={activeStep} sx={{ mb: 4 }} alternativeLabel={isMobile}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {/* ステップ1: 基本情報 */}
        {activeStep === 0 && (
          <>
            <TextField
              fullWidth
              label="ログインID"
              value={formData.loginId}
              onChange={handleChange('loginId')}
              required
              sx={{ mb: 2 }}
              helperText="4文字以上で入力してください"
            />
            <TextField
              fullWidth
              label="パスワード"
              type="password"
              value={formData.password}
              onChange={handleChange('password')}
              required
              sx={{ mb: 2 }}
              helperText="6文字以上で入力してください"
            />
            <TextField
              fullWidth
              label="パスワード（確認）"
              type="password"
              value={formData.confirmPassword}
              onChange={handleChange('confirmPassword')}
              required
              sx={{ mb: 2 }}
            />
            <TextField
              fullWidth
              label="名前"
              value={formData.name}
              onChange={handleChange('name')}
              required
              sx={{ mb: 2 }}
            />
          </>
        )}

        {/* ステップ2: 連絡先 */}
        {activeStep === 1 && (
          <>
            <TextField
              fullWidth
              label="メールアドレス"
              type="email"
              value={formData.email}
              onChange={handleChange('email')}
              required
              sx={{ mb: 2 }}
            />
            <TextField
              fullWidth
              label="電話番号"
              value={formData.phone}
              onChange={handleChange('phone')}
              required
              sx={{ mb: 2 }}
              placeholder="例: 090-1234-5678"
            />
          </>
        )}

        {/* ステップ3: 確認 */}
        {activeStep === 2 && (
          <Box sx={{ bgcolor: 'grey.50', p: 3, borderRadius: 2 }}>
            <Typography variant="subtitle2" color="text.secondary" gutterBottom>
              入力内容の確認
            </Typography>
            <Box sx={{ display: 'grid', gap: 1.5 }}>
              <Box>
                <Typography variant="caption" color="text.secondary">ログインID</Typography>
                <Typography fontWeight="medium">{formData.loginId}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">名前</Typography>
                <Typography fontWeight="medium">{formData.name}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">メールアドレス</Typography>
                <Typography fontWeight="medium">{formData.email}</Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">電話番号</Typography>
                <Typography fontWeight="medium">{formData.phone}</Typography>
              </Box>
            </Box>
            <Alert severity="info" sx={{ mt: 2 }}>
              個人アカウントは管理者権限が付与されます
            </Alert>
          </Box>
        )}

        {/* ボタン */}
        <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
          {activeStep > 0 && (
            <Button
              variant="outlined"
              color="primary"
              onClick={handleBack}
              sx={{ flex: 1 }}
            >
              戻る
            </Button>
          )}
          <Button
            variant="contained"
            onClick={handleNext}
            startIcon={activeStep === steps.length - 1 ? <PersonAdd /> : undefined}
            sx={{
              flex: 1,
              bgcolor: 'primary.main',
              color: 'primary.contrastText',
              '&:hover': {
                bgcolor: 'primary.dark',
              },
            }}
          >
            {activeStep === steps.length - 1 ? '登録する' : '次へ'}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
};

export default PersonalRegisterPage;
