import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Alert,
  Stepper,
  Step,
  StepLabel,
  useMediaQuery,
  useTheme,
  Divider,
} from '@mui/material';
import { ArrowBack, Business, CheckCircle } from '@mui/icons-material';
import useUserStore from '../../store/userStore';

const steps = ['企業情報', '管理者アカウント', '確認'];

const CompanyRegisterPage = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const addCompany = useUserStore((state) => state.addCompany);
  const addUser = useUserStore((state) => state.addUser);
  const companies = useUserStore((state) => state.companies);

  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    // 企業情報
    companyName: '',
    companyId: '',
    companyEmail: '',
    companyPhone: '',
    companyAddress: '',
    // 管理者アカウント
    adminEmployeeId: '',
    adminPassword: '',
    adminConfirmPassword: '',
    adminName: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [field]: e.target.value });
    setError('');
  };

  const validateStep = () => {
    switch (activeStep) {
      case 0:
        if (!formData.companyName.trim()) {
          setError('企業名を入力してください');
          return false;
        }
        if (!formData.companyId.trim()) {
          setError('企業IDを入力してください');
          return false;
        }
        if (formData.companyId.length < 4) {
          setError('企業IDは4文字以上で入力してください');
          return false;
        }
        // 重複チェック
        const duplicate = companies.find((c) => c.companyId === formData.companyId);
        if (duplicate) {
          setError('この企業IDは既に使用されています');
          return false;
        }
        if (!formData.companyEmail.trim()) {
          setError('企業メールアドレスを入力してください');
          return false;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.companyEmail)) {
          setError('正しいメールアドレスを入力してください');
          return false;
        }
        if (!formData.companyPhone.trim()) {
          setError('企業電話番号を入力してください');
          return false;
        }
        break;
      case 1:
        if (!formData.adminEmployeeId.trim()) {
          setError('従業員IDを入力してください');
          return false;
        }
        if (!formData.adminPassword) {
          setError('パスワードを入力してください');
          return false;
        }
        if (formData.adminPassword.length < 6) {
          setError('パスワードは6文字以上で入力してください');
          return false;
        }
        if (formData.adminPassword !== formData.adminConfirmPassword) {
          setError('パスワードが一致しません');
          return false;
        }
        if (!formData.adminName.trim()) {
          setError('管理者名を入力してください');
          return false;
        }
        break;
    }
    return true;
  };

  const handleNext = () => {
    if (!validateStep()) return;

    if (activeStep === steps.length - 1) {
      // 企業登録
      addCompany({
        companyId: formData.companyId,
        name: formData.companyName,
        email: formData.companyEmail,
        phone: formData.companyPhone,
        address: formData.companyAddress,
      });

      // 管理者アカウント登録
      addUser({
        accountType: 'employee',
        companyId: formData.companyId,
        employeeId: formData.adminEmployeeId,
        password: formData.adminPassword,
        name: formData.adminName,
        permissionId: 'admin', // 管理者権限
      });

      setSuccess(true);
    } else {
      setActiveStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
    setError('');
  };

  if (success) {
    return (
      <Box
        sx={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          bgcolor: 'primary.light',
          p: 2,
        }}
      >
        <Paper sx={{ p: 4, textAlign: 'center', maxWidth: 450, borderRadius: 3 }}>
          <CheckCircle sx={{ fontSize: 64, color: 'success.main', mb: 2 }} />
          <Typography variant="h5" fontWeight="bold" gutterBottom>
            企業登録完了！
          </Typography>
          <Typography color="text.secondary" sx={{ mb: 3 }}>
            企業アカウントと管理者アカウントが作成されました。
          </Typography>
          <Box sx={{ bgcolor: 'grey.100', p: 2, borderRadius: 2, mb: 3, textAlign: 'left' }}>
            <Typography variant="subtitle2" fontWeight="bold" gutterBottom>
              ログイン情報
            </Typography>
            <Typography variant="body2">
              企業ID: <strong>{formData.companyId}</strong>
            </Typography>
            <Typography variant="body2">
              従業員ID: <strong>{formData.adminEmployeeId}</strong>
            </Typography>
          </Box>
          <Alert severity="info" sx={{ mb: 3, textAlign: 'left' }}>
            従業員の追加は、ログイン後の設定画面から行えます。
          </Alert>
          <Button
            variant="contained"
            fullWidth
            onClick={() => navigate('/login')}
            sx={{
              bgcolor: 'primary.main',
              color: 'primary.contrastText',
              '&:hover': {
                bgcolor: 'primary.dark',
              },
            }}
          >
            ログインページへ
          </Button>
        </Paper>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        bgcolor: 'primary.light',
        p: 2,
      }}
    >
      <Paper sx={{ p: { xs: 3, sm: 4 }, width: '100%', maxWidth: 550, borderRadius: 3 }}>
        {/* ヘッダー */}
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <Button
            startIcon={<ArrowBack />}
            onClick={() => navigate('/login')}
            sx={{ mr: 2 }}
          >
            戻る
          </Button>
          <Typography variant={isMobile ? 'h6' : 'h5'} fontWeight="bold">
            企業アカウント登録
          </Typography>
        </Box>

        {/* ステッパー */}
        <Stepper activeStep={activeStep} sx={{ mb: 4 }} alternativeLabel={isMobile}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {/* ステップ1: 企業情報 */}
        {activeStep === 0 && (
          <>
            <TextField
              fullWidth
              label="企業名"
              value={formData.companyName}
              onChange={handleChange('companyName')}
              required
              sx={{ mb: 2 }}
            />
            <TextField
              fullWidth
              label="企業ID"
              value={formData.companyId}
              onChange={handleChange('companyId')}
              required
              sx={{ mb: 2 }}
              helperText="従業員がログインに使用するIDです（4文字以上）"
              placeholder="例: MYCOMPANY001"
            />
            <TextField
              fullWidth
              label="企業メールアドレス"
              type="email"
              value={formData.companyEmail}
              onChange={handleChange('companyEmail')}
              required
              sx={{ mb: 2 }}
            />
            <TextField
              fullWidth
              label="企業電話番号"
              value={formData.companyPhone}
              onChange={handleChange('companyPhone')}
              required
              sx={{ mb: 2 }}
              placeholder="例: 03-1234-5678"
            />
            <TextField
              fullWidth
              label="住所（任意）"
              value={formData.companyAddress}
              onChange={handleChange('companyAddress')}
              sx={{ mb: 2 }}
            />
          </>
        )}

        {/* ステップ2: 管理者アカウント */}
        {activeStep === 1 && (
          <>
            <Alert severity="info" sx={{ mb: 2 }}>
              企業の管理者アカウントを作成します。
              このアカウントで従業員の追加や権限設定が行えます。
            </Alert>
            <TextField
              fullWidth
              label="従業員ID（管理者用）"
              value={formData.adminEmployeeId}
              onChange={handleChange('adminEmployeeId')}
              required
              sx={{ mb: 2 }}
              placeholder="例: ADMIN001"
            />
            <TextField
              fullWidth
              label="パスワード"
              type="password"
              value={formData.adminPassword}
              onChange={handleChange('adminPassword')}
              required
              sx={{ mb: 2 }}
              helperText="6文字以上で入力してください"
            />
            <TextField
              fullWidth
              label="パスワード（確認）"
              type="password"
              value={formData.adminConfirmPassword}
              onChange={handleChange('adminConfirmPassword')}
              required
              sx={{ mb: 2 }}
            />
            <TextField
              fullWidth
              label="管理者名"
              value={formData.adminName}
              onChange={handleChange('adminName')}
              required
              sx={{ mb: 2 }}
            />
          </>
        )}

        {/* ステップ3: 確認 */}
        {activeStep === 2 && (
          <Box>
            <Box sx={{ bgcolor: 'grey.50', p: 3, borderRadius: 2, mb: 2 }}>
              <Typography variant="subtitle2" fontWeight="bold" gutterBottom>
                企業情報
              </Typography>
              <Box sx={{ display: 'grid', gap: 1 }}>
                <Box>
                  <Typography variant="caption" color="text.secondary">企業名</Typography>
                  <Typography fontWeight="medium">{formData.companyName}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">企業ID</Typography>
                  <Typography fontWeight="medium">{formData.companyId}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">メールアドレス</Typography>
                  <Typography fontWeight="medium">{formData.companyEmail}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">電話番号</Typography>
                  <Typography fontWeight="medium">{formData.companyPhone}</Typography>
                </Box>
              </Box>
            </Box>

            <Divider sx={{ my: 2 }} />

            <Box sx={{ bgcolor: 'primary.50', p: 3, borderRadius: 2 }}>
              <Typography variant="subtitle2" fontWeight="bold" gutterBottom>
                管理者アカウント
              </Typography>
              <Box sx={{ display: 'grid', gap: 1 }}>
                <Box>
                  <Typography variant="caption" color="text.secondary">従業員ID</Typography>
                  <Typography fontWeight="medium">{formData.adminEmployeeId}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">名前</Typography>
                  <Typography fontWeight="medium">{formData.adminName}</Typography>
                </Box>
                <Box>
                  <Typography variant="caption" color="text.secondary">権限</Typography>
                  <Typography fontWeight="medium" color="primary">管理者</Typography>
                </Box>
              </Box>
            </Box>
          </Box>
        )}

        {/* ボタン */}
        <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
          {activeStep > 0 && (
            <Button
              variant="outlined"
              color="primary"
              onClick={handleBack}
              sx={{ flex: 1 }}
            >
              戻る
            </Button>
          )}
          <Button
            variant="contained"
            onClick={handleNext}
            startIcon={activeStep === steps.length - 1 ? <Business /> : undefined}
            sx={{
              flex: 1,
              bgcolor: 'primary.main',
              color: 'primary.contrastText',
              '&:hover': {
                bgcolor: 'primary.dark',
              },
            }}
          >
            {activeStep === steps.length - 1 ? '登録する' : '次へ'}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
};

export default CompanyRegisterPage;
