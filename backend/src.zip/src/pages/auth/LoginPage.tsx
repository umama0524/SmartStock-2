import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Alert,
  Divider,
} from '@mui/material';
import { Login as LoginIcon } from '@mui/icons-material';
import { useAuthStore } from '../../store/authStore';

// デモユーザー
const DEMO_USERS = [
  { username: 'admin', password: 'password', name: '管理者', role: 'admin' },
  { username: 'inventory', password: 'password', name: '在庫 太郎', role: 'inventory' },
  { username: 'purchase', password: 'password', name: '発注 花子', role: 'purchase' },
  { username: 'sales', password: 'password', name: '販売 次郎', role: 'sales' },
  { username: 'approver', password: 'password', name: '承認 部長', role: 'approver' },
];

const LoginPage = () => {
  const navigate = useNavigate();
  const login = useAuthStore((state) => state.login);

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const user = DEMO_USERS.find(
      (u) => u.username === username && u.password === password
    );

    if (user) {
      login({
        id: user.username,
        name: user.name,
        username: user.username,
        role: user.role as 'admin' | 'inventory' | 'purchase' | 'sales' | 'approver' | 'viewer',
        isAdmin: user.role === 'admin',
      });
      navigate('/');
    } else {
      setError('ユーザー名またはパスワードが正しくありません');
    }
  };

  const handleQuickLogin = (username: string) => {
    const user = DEMO_USERS.find((u) => u.username === username);
    if (user) {
      login({
        id: user.username,
        name: user.name,
        username: user.username,
        role: user.role as 'admin' | 'inventory' | 'purchase' | 'sales' | 'approver' | 'viewer',
        isAdmin: user.role === 'admin',
      });
      navigate('/');
    }
  };

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        bgcolor: 'primary.light',
        p: 2,
      }}
    >
      <Paper
        sx={{
          p: 4,
          width: '100%',
          maxWidth: 400,
          borderRadius: 3,
        }}
      >
        {/* ロゴ */}
        <Box sx={{ textAlign: 'center', mb: 3 }}>
          <Typography variant="h4" fontWeight="bold" color="primary.main">
            SmartStock
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            在庫管理システム
          </Typography>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <form onSubmit={handleLogin}>
          <TextField
            fullWidth
            label="ユーザー名"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            sx={{ mb: 2 }}
            autoComplete="username"
          />

          <TextField
            fullWidth
            label="パスワード"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            sx={{ mb: 3 }}
            autoComplete="current-password"
          />

          <Button
            type="submit"
            variant="contained"
            fullWidth
            size="large"
            startIcon={<LoginIcon />}
            sx={{
              py: 1.5,
              bgcolor: 'primary.main',
              color: 'primary.contrastText',
              transition: 'box-shadow 0.2s ease',
              '&:hover': {
                boxShadow: 4,
                bgcolor: 'primary.dark',
              },
            }}
          >
            ログイン
          </Button>
        </form>

        <Divider sx={{ my: 3 }}>
          <Typography variant="body2" color="text.secondary">
            クイックログイン
          </Typography>
        </Divider>

        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
          <Button
            variant="outlined"
            size="small"
            onClick={() => handleQuickLogin('admin')}
            sx={{ flex: '1 1 45%' }}
          >
            管理者
          </Button>
          <Button
            variant="outlined"
            size="small"
            onClick={() => handleQuickLogin('approver')}
            sx={{ flex: '1 1 45%' }}
          >
            承認者
          </Button>
          <Button
            variant="outlined"
            size="small"
            onClick={() => handleQuickLogin('inventory')}
            sx={{ flex: '1 1 45%' }}
          >
            在庫担当
          </Button>
          <Button
            variant="outlined"
            size="small"
            onClick={() => handleQuickLogin('purchase')}
            sx={{ flex: '1 1 45%' }}
          >
            発注担当
          </Button>
          <Button
            variant="outlined"
            size="small"
            onClick={() => handleQuickLogin('sales')}
            sx={{ flex: '1 1 45%' }}
          >
            販売担当
          </Button>
        </Box>

        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 2, textAlign: 'center' }}>
          パスワード: password（全アカウント共通）
        </Typography>
      </Paper>
    </Box>
  );
};

export default LoginPage;
