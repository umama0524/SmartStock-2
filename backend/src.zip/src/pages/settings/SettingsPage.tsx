import { useState } from 'react';
import {
  Box,
  Paper,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  Alert,
  Tabs,
  Tab,
} from '@mui/material';
import { Add, Edit, Delete, PersonAdd, Security, Business } from '@mui/icons-material';
import { useAuthStore } from '../../store/authStore';

interface Employee {
  id: string;
  employeeId: string;
  name: string;
  role: string;
  isActive: boolean;
}

const initialEmployees: Employee[] = [
  { id: '1', employeeId: 'EMP001', name: '管理者', role: 'admin', isActive: true },
  { id: '2', employeeId: 'EMP002', name: '在庫 太郎', role: 'inventory', isActive: true },
  { id: '3', employeeId: 'EMP003', name: '発注 花子', role: 'purchase', isActive: true },
  { id: '4', employeeId: 'EMP004', name: '販売 次郎', role: 'sales', isActive: true },
  { id: '5', employeeId: 'EMP005', name: '承認 部長', role: 'approver', isActive: true },
];

const roleOptions = [
  { value: 'admin', label: '管理者', color: 'error' as const },
  { value: 'approver', label: '承認者', color: 'warning' as const },
  { value: 'inventory', label: '在庫担当', color: 'primary' as const },
  { value: 'purchase', label: '発注担当', color: 'info' as const },
  { value: 'sales', label: '販売担当', color: 'success' as const },
  { value: 'viewer', label: '閲覧者', color: 'default' as const },
];

const SettingsPage = () => {
  const user = useAuthStore((state) => state.user);
  const isAdmin = user?.role === 'admin';

  const [employees, setEmployees] = useState<Employee[]>(initialEmployees);
  const [tabValue, setTabValue] = useState(0);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [employeeToDelete, setEmployeeToDelete] = useState<Employee | null>(null);
  const [formData, setFormData] = useState({ employeeId: '', name: '', role: 'viewer', password: '' });
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const handleAddEmployee = () => {
    setEditingEmployee(null);
    setFormData({ employeeId: '', name: '', role: 'viewer', password: '' });
    setDialogOpen(true);
  };

  const handleEditEmployee = (employee: Employee) => {
    setEditingEmployee(employee);
    setFormData({ employeeId: employee.employeeId, name: employee.name, role: employee.role, password: '' });
    setDialogOpen(true);
  };

  const handleSaveEmployee = () => {
    setError('');
    if (!formData.employeeId.trim() || !formData.name.trim()) {
      setError('必須項目を入力してください');
      return;
    }
    if (!editingEmployee && !formData.password.trim()) {
      setError('パスワードを入力してください');
      return;
    }

    if (editingEmployee) {
      setEmployees(employees.map(emp => 
        emp.id === editingEmployee.id 
          ? { ...emp, employeeId: formData.employeeId, name: formData.name, role: formData.role }
          : emp
      ));
      setSuccess('従業員情報を更新しました');
    } else {
      setEmployees([...employees, {
        id: `emp-${Date.now()}`,
        employeeId: formData.employeeId,
        name: formData.name,
        role: formData.role,
        isActive: true,
      }]);
      setSuccess('従業員を追加しました');
    }
    setDialogOpen(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleToggleActive = (id: string) => {
    setEmployees(employees.map(emp => emp.id === id ? { ...emp, isActive: !emp.isActive } : emp));
  };

  const handleRoleChange = (id: string, newRole: string) => {
    setEmployees(employees.map(emp => emp.id === id ? { ...emp, role: newRole } : emp));
    setSuccess('権限を変更しました');
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleConfirmDelete = () => {
    if (employeeToDelete) {
      setEmployees(employees.filter(emp => emp.id !== employeeToDelete.id));
      setSuccess('従業員を削除しました');
      setTimeout(() => setSuccess(''), 3000);
    }
    setDeleteDialogOpen(false);
  };

  const getRoleChip = (role: string) => {
    const option = roleOptions.find(r => r.value === role);
    return <Chip label={option?.label || role} color={option?.color || 'default'} size="small" sx={{ minWidth: 80 }} />;
  };

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Paper sx={{ mb: 3 }}>
        <Tabs value={tabValue} onChange={(_, v) => setTabValue(v)} sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tab icon={<PersonAdd />} iconPosition="start" label="アカウント管理" />
          <Tab icon={<Security />} iconPosition="start" label="権限一覧" />
          <Tab icon={<Business />} iconPosition="start" label="システム情報" />
        </Tabs>
      </Paper>

      {tabValue === 0 && (
        <Paper sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h6" fontWeight="bold">従業員一覧</Typography>
            {isAdmin && (
              <Button variant="contained" startIcon={<Add />} onClick={handleAddEmployee}>従業員追加</Button>
            )}
          </Box>

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow sx={{ bgcolor: 'grey.100' }}>
                  <TableCell>従業員ID</TableCell>
                  <TableCell>名前</TableCell>
                  <TableCell align="center">権限</TableCell>
                  <TableCell align="center">状態</TableCell>
                  {isAdmin && <TableCell align="center">操作</TableCell>}
                </TableRow>
              </TableHead>
              <TableBody>
                {employees.map((employee) => (
                  <TableRow key={employee.id}>
                    <TableCell><Typography fontWeight="medium">{employee.employeeId}</Typography></TableCell>
                    <TableCell>{employee.name}</TableCell>
                    <TableCell align="center">
                      {isAdmin && employee.id !== '1' ? (
                        <Select value={employee.role} size="small" onChange={(e) => handleRoleChange(employee.id, e.target.value)} sx={{ minWidth: 100 }}>
                          {roleOptions.map((opt) => <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>)}
                        </Select>
                      ) : getRoleChip(employee.role)}
                    </TableCell>
                    <TableCell align="center">
                      {isAdmin && employee.id !== '1' ? (
                        <Switch checked={employee.isActive} onChange={() => handleToggleActive(employee.id)} color="success" size="small" />
                      ) : (
                        <Chip label={employee.isActive ? '有効' : '無効'} color={employee.isActive ? 'success' : 'default'} size="small" />
                      )}
                    </TableCell>
                    {isAdmin && (
                      <TableCell align="center">
                        {employee.id !== '1' && (
                          <>
                            <IconButton size="small" onClick={() => handleEditEmployee(employee)}><Edit fontSize="small" /></IconButton>
                            <IconButton size="small" color="error" onClick={() => { setEmployeeToDelete(employee); setDeleteDialogOpen(true); }}>
                              <Delete fontSize="small" />
                            </IconButton>
                          </>
                        )}
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          {!isAdmin && <Alert severity="info" sx={{ mt: 2 }}>従業員の追加・編集は管理者のみ可能です</Alert>}
        </Paper>
      )}

      {tabValue === 1 && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" fontWeight="bold" sx={{ mb: 3 }}>権限一覧</Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
            {roleOptions.map((role) => (
              <Paper key={role.value} variant="outlined" sx={{ p: 2, flex: '1 1 300px', minWidth: 250 }}>
                <Chip label={role.label} color={role.color} size="small" sx={{ mb: 1 }} />
                <Typography variant="body2" color="text.secondary">
                  {role.value === 'admin' && '全機能へのフルアクセス、ユーザー管理'}
                  {role.value === 'approver' && '発注・在庫調整の承認権限'}
                  {role.value === 'inventory' && '在庫の入出庫・調整操作'}
                  {role.value === 'purchase' && '発注の作成・編集'}
                  {role.value === 'sales' && '受注の作成・編集'}
                  {role.value === 'viewer' && '全画面の閲覧のみ'}
                </Typography>
              </Paper>
            ))}
          </Box>
        </Paper>
      )}

      {tabValue === 2 && (
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" fontWeight="bold" sx={{ mb: 3 }}>システム情報</Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
            <Box sx={{ flex: '1 1 200px' }}>
              <Typography variant="body2" color="text.secondary">システム名</Typography>
              <Typography fontWeight="medium">SmartStock</Typography>
            </Box>
            <Box sx={{ flex: '1 1 200px' }}>
              <Typography variant="body2" color="text.secondary">バージョン</Typography>
              <Typography fontWeight="medium">1.0.0</Typography>
            </Box>
            <Box sx={{ flex: '1 1 200px' }}>
              <Typography variant="body2" color="text.secondary">ログインユーザー</Typography>
              <Typography fontWeight="medium">{user?.name || '不明'}</Typography>
            </Box>
            <Box sx={{ flex: '1 1 200px' }}>
              <Typography variant="body2" color="text.secondary">権限</Typography>
              <Typography fontWeight="medium">{user?.role === 'admin' ? '管理者' : user?.role || '不明'}</Typography>
            </Box>
          </Box>
        </Paper>
      )}

      {/* 従業員追加/編集ダイアログ */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editingEmployee ? '従業員編集' : '従業員追加'}</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          <TextField fullWidth label="従業員ID" value={formData.employeeId} onChange={(e) => setFormData({ ...formData, employeeId: e.target.value })} sx={{ mt: 1, mb: 2 }} required />
          <TextField fullWidth label={editingEmployee ? 'パスワード（変更時のみ）' : 'パスワード'} type="password" value={formData.password} onChange={(e) => setFormData({ ...formData, password: e.target.value })} sx={{ mb: 2 }} required={!editingEmployee} />
          <TextField fullWidth label="名前" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} sx={{ mb: 2 }} required />
          <FormControl fullWidth>
            <InputLabel>権限</InputLabel>
            <Select value={formData.role} label="権限" onChange={(e) => setFormData({ ...formData, role: e.target.value })}>
              {roleOptions.map((opt) => <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>)}
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>キャンセル</Button>
          <Button variant="contained" onClick={handleSaveEmployee}>保存</Button>
        </DialogActions>
      </Dialog>

      {/* 削除確認ダイアログ */}
      <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)}>
        <DialogTitle>削除確認</DialogTitle>
        <DialogContent><Typography>「{employeeToDelete?.name}」を削除しますか？</Typography></DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>キャンセル</Button>
          <Button variant="contained" color="error" onClick={handleConfirmDelete}>削除</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SettingsPage;
