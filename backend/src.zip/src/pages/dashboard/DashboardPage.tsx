import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Chip,
  LinearProgress,
  Button,
} from '@mui/material';
import {
  Inventory2,
  Warning,
  PendingActions,
  LocalShipping,
  Error as ErrorIcon,
  Info,
  TrendingUp,
  TrendingDown,
  ArrowForward,
} from '@mui/icons-material';
import useInventoryStore from '../../store/inventoryStore';
import usePurchaseStore from '../../store/purchaseStore';
import useSalesStore from '../../store/salesStore';
import useApprovalStore from '../../store/approvalStore';

const DashboardPage = () => {
  const navigate = useNavigate();
  const inventory = useInventoryStore((state) => state.inventory);
  const purchaseOrders = usePurchaseStore((state) => state.orders);
  const salesOrders = useSalesStore((state) => state.orders);
  const approvals = useApprovalStore((state) => state.approvals);

  const kpis = useMemo(() => {
    const totalInventory = inventory.reduce((sum, item) => sum + item.quantity, 0);
    const criticalItems = inventory.filter((item) => item.status === 'critical').length;
    const lowItems = inventory.filter((item) => item.status === 'low').length;
    const pendingApprovals = approvals.filter((a) => a.status === 'pending').length;
    const todayShipments = salesOrders.filter(
      (order) =>
        order.deliveryDate === new Date().toISOString().split('T')[0] &&
        !['delivered', 'cancelled'].includes(order.status)
    ).length;

    return {
      totalInventory,
      criticalItems,
      lowItems,
      pendingApprovals,
      todayShipments,
    };
  }, [inventory, approvals, salesOrders]);

  const alerts = useMemo(() => {
    const alertList: { id: string; severity: 'error' | 'warning' | 'info'; message: string; link?: string }[] = [];

    inventory
      .filter((item) => item.status === 'critical')
      .forEach((item) => {
        alertList.push({
          id: `critical-${item.id}`,
          severity: 'error',
          message: `${item.productName}の在庫が危険水準です（残: ${item.quantity}）`,
          link: `/inventory/${item.id}`,
        });
      });

    if (kpis.pendingApprovals > 0) {
      alertList.push({
        id: 'pending-approvals',
        severity: 'warning',
        message: `${kpis.pendingApprovals}件の承認待ちがあります`,
        link: '/approvals',
      });
    }

    if (kpis.todayShipments > 0) {
      alertList.push({
        id: 'today-shipments',
        severity: 'info',
        message: `本日出荷予定: ${kpis.todayShipments}件`,
        link: '/sales',
      });
    }

    return alertList;
  }, [inventory, kpis]);

  const recentActivity = useMemo(() => {
    const activities: { id: string; type: string; message: string; date: string }[] = [];

    purchaseOrders
      .slice(0, 3)
      .forEach((order) => {
        activities.push({
          id: `po-${order.id}`,
          type: '発注',
          message: `${order.poNumber} - ${order.supplierName}`,
          date: order.orderDate,
        });
      });

    salesOrders
      .slice(0, 3)
      .forEach((order) => {
        activities.push({
          id: `so-${order.id}`,
          type: '受注',
          message: `${order.soNumber} - ${order.customerName}`,
          date: order.orderDate,
        });
      });

    return activities.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);
  }, [purchaseOrders, salesOrders]);

  const inventorySummary = useMemo(() => {
    const normal = inventory.filter((item) => item.status === 'normal').length;
    const low = inventory.filter((item) => item.status === 'low').length;
    const critical = inventory.filter((item) => item.status === 'critical').length;
    const total = inventory.length;

    return { normal, low, critical, total };
  }, [inventory]);

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          {/* 在庫総数カード */}
          <Card
            sx={{
              bgcolor: 'primary.light',
              color: 'primary.dark',
              cursor: 'pointer',
              transition: 'background-color 0.2s ease, color 0.2s ease',
              '&:hover': {
                bgcolor: 'primary.main',
                color: 'primary.contrastText',
              },
            }}
            onClick={() => navigate('/inventory')}
          >
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    在庫総数
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {kpis.totalInventory.toLocaleString()}
                  </Typography>
                </Box>
                <Inventory2 sx={{ fontSize: 40, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          {/* 危険在庫カード */}
          <Card
            sx={{
              bgcolor: 'error.light',
              color: 'error.dark',
              cursor: 'pointer',
              transition: 'background-color 0.2s ease, color 0.2s ease',
              '&:hover': {
                bgcolor: 'error.main',
                color: 'error.contrastText',
              },
            }}
            onClick={() => navigate('/inventory')}
          >
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    安全在庫割れ
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {kpis.criticalItems}
                  </Typography>
                </Box>
                <Warning sx={{ fontSize: 40, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          {/* 承認待ちカード */}
          <Card
            sx={{
              bgcolor: 'warning.light',
              color: 'warning.dark',
              cursor: 'pointer',
              transition: 'background-color 0.2s ease, color 0.2s ease',
              '&:hover': {
                bgcolor: 'warning.main',
                color: 'warning.contrastText',
              },
            }}
            onClick={() => navigate('/approvals')}
          >
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    承認待ち
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {kpis.pendingApprovals}
                  </Typography>
                </Box>
                <PendingActions sx={{ fontSize: 40, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          {/* 本日出荷予定カード */}
          <Card
            sx={{
              bgcolor: 'success.light',
              color: 'success.dark',
              cursor: 'pointer',
              transition: 'background-color 0.2s ease, color 0.2s ease',
              '&:hover': {
                bgcolor: 'success.main',
                color: 'success.contrastText',
              },
            }}
            onClick={() => navigate('/sales')}
          >
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <Box>
                  <Typography variant="body2" sx={{ opacity: 0.9 }}>
                    本日出荷予定
                  </Typography>
                  <Typography variant="h4" fontWeight="bold">
                    {kpis.todayShipments}
                  </Typography>
                </Box>
                <LocalShipping sx={{ fontSize: 40, opacity: 0.8 }} />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              アラート
            </Typography>
            {alerts.length > 0 ? (
              <List>
                {alerts.map((alert) => (
                  <ListItem
                    key={alert.id}
                    sx={{
                      bgcolor:
                        alert.severity === 'error'
                          ? 'error.light'
                          : alert.severity === 'warning'
                          ? 'warning.light'
                          : 'info.light',
                      color:
                        alert.severity === 'error'
                          ? 'error.dark'
                          : alert.severity === 'warning'
                          ? 'warning.dark'
                          : 'info.dark',
                      borderRadius: 2,
                      mb: 1,
                      cursor: alert.link ? 'pointer' : 'default',
                      transition: 'background-color 0.2s ease, color 0.2s ease',
                      '&:hover': alert.link
                        ? {
                            bgcolor:
                              alert.severity === 'error'
                                ? 'error.main'
                                : alert.severity === 'warning'
                                ? 'warning.main'
                                : 'info.main',
                            color:
                              alert.severity === 'error'
                                ? 'error.contrastText'
                                : alert.severity === 'warning'
                                ? 'warning.contrastText'
                                : 'info.contrastText',
                          }
                        : {},
                    }}
                    onClick={() => alert.link && navigate(alert.link)}
                  >
                    <ListItemIcon>
                      {alert.severity === 'error' ? (
                        <ErrorIcon color="error" />
                      ) : alert.severity === 'warning' ? (
                        <Warning color="warning" />
                      ) : (
                        <Info color="info" />
                      )}
                    </ListItemIcon>
                    <ListItemText primary={alert.message} />
                    {alert.link && <ArrowForward color="action" />}
                  </ListItem>
                ))}
              </List>
            ) : (
              <Typography color="text.secondary" sx={{ py: 3, textAlign: 'center' }}>
                アラートはありません
              </Typography>
            )}
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              在庫状況
            </Typography>
            <Box sx={{ mt: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2">正常</Typography>
                <Typography variant="body2" fontWeight="medium">
                  {inventorySummary.normal}件
                </Typography>
              </Box>
              <LinearProgress
                variant="determinate"
                value={(inventorySummary.normal / inventorySummary.total) * 100}
                color="success"
                sx={{ height: 8, borderRadius: 4, mb: 2 }}
              />

              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2">低在庫</Typography>
                <Typography variant="body2" fontWeight="medium">
                  {inventorySummary.low}件
                </Typography>
              </Box>
              <LinearProgress
                variant="determinate"
                value={(inventorySummary.low / inventorySummary.total) * 100}
                color="warning"
                sx={{ height: 8, borderRadius: 4, mb: 2 }}
              />

              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2">危険</Typography>
                <Typography variant="body2" fontWeight="medium">
                  {inventorySummary.critical}件
                </Typography>
              </Box>
              <LinearProgress
                variant="determinate"
                value={(inventorySummary.critical / inventorySummary.total) * 100}
                color="error"
                sx={{ height: 8, borderRadius: 4 }}
              />
            </Box>

            {/*
              The stock list button uses a neutral outlined style to avoid
              competing with the coloured KPI cards.  It relies on the
              theme's divider and text colours for the border and text,
              creating a subtle call to action.  On hover the background
              becomes a light grey, mimicking a raised surface without
              pulling focus away from the rest of the dashboard.
             */}
            <Button
              fullWidth
              variant="outlined"
              sx={{
                mt: 3,
                color: 'text.primary',
                borderColor: 'divider',
                backgroundColor: 'background.paper',
                borderRadius: 2,
                fontWeight: 600,
                transition: 'background-color 0.2s ease, border-color 0.2s ease',
                '&:hover': {
                  backgroundColor: 'grey.50',
                  borderColor: 'grey.300',
                },
              }}
              onClick={() => navigate('/inventory')}
            >
              在庫一覧を見る
            </Button>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              最近のアクティビティ
            </Typography>
            <List>
              {recentActivity.map((activity, index) => (
                <ListItem
                  key={activity.id}
                  divider={index < recentActivity.length - 1}
                  sx={{ px: 0 }}
                >
                  <ListItemIcon>
                    {activity.type === '発注' ? (
                      <TrendingUp color="primary" />
                    ) : (
                      <TrendingDown color="success" />
                    )}
                  </ListItemIcon>
                  <ListItemText
                    primary={activity.message}
                    secondary={`${activity.type} - ${activity.date}`}
                  />
                  <Chip
                    label={activity.type}
                    size="small"
                    color={activity.type === '発注' ? 'primary' : 'success'}
                    variant="outlined"
                    sx={{ minWidth: 60 }}
                  />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default DashboardPage;
