import { useState, useMemo } from 'react';
import {
  Box,
  Paper,
  Typography,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Chip,
  Tabs,
  Tab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
} from '@mui/material';
import { CheckCircle, Cancel, Visibility } from '@mui/icons-material';
import useApprovalStore from '../../store/approvalStore';
import { useAuthStore } from '../../store/authStore';

const buttonStyle = {
  transition: 'all 0.3s ease',
  '&:hover': { transform: 'translateY(-2px)', boxShadow: 4 },
  minWidth: 100,
};

interface Approval {
  id: string;
  type: 'purchase' | 'adjustment';
  referenceId: string;
  referenceNumber: string;
  title: string;
  requesterId: string;
  requesterName: string;
  requestDate: string;
  status: 'pending' | 'approved' | 'rejected';
  amount?: number;
  itemCount?: number;
  note?: string;
  approverName?: string;
  approvedDate?: string;
  rejectReason?: string;
}

const ApprovalListPage = () => {
  const user = useAuthStore((state) => state.user);
  const approvals = useApprovalStore((state) => state.approvals) as Approval[];
  const approveRequest = useApprovalStore((state) => state.approve);
  const rejectRequest = useApprovalStore((state) => state.reject);

  const canApprove = user?.role === 'admin' || user?.role === 'approver';

  const [tabValue, setTabValue] = useState(0);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [selectedApproval, setSelectedApproval] = useState<Approval | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [success, setSuccess] = useState('');

  const filteredApprovals = useMemo(() => {
    if (tabValue === 0) {
      return approvals.filter((a) => a.status === 'pending');
    } else if (tabValue === 1) {
      return approvals.filter((a) => a.status === 'approved');
    } else {
      return approvals.filter((a) => a.status === 'rejected');
    }
  }, [approvals, tabValue]);

  const getStatusChip = (status: Approval['status']) => {
    const chipStyle = { minWidth: 80, justifyContent: 'center' };
    switch (status) {
      case 'pending':
        return <Chip label="承認待ち" color="warning" size="small" sx={chipStyle} />;
      case 'approved':
        return <Chip label="承認済" color="success" size="small" sx={chipStyle} />;
      case 'rejected':
        return <Chip label="却下" color="error" size="small" sx={chipStyle} />;
      default:
        return <Chip label={status} size="small" sx={chipStyle} />;
    }
  };

  const getTypeChip = (type: Approval['type']) => {
    const chipStyle = { minWidth: 80, justifyContent: 'center' };
    switch (type) {
      case 'purchase':
        return <Chip label="発注" color="primary" size="small" variant="outlined" sx={chipStyle} />;
      case 'adjustment':
        return <Chip label="在庫調整" color="info" size="small" variant="outlined" sx={chipStyle} />;
      default:
        return <Chip label={type} size="small" variant="outlined" sx={chipStyle} />;
    }
  };

  const handleViewDetail = (approval: Approval) => {
    setSelectedApproval(approval);
    setDetailOpen(true);
  };

  const handleApprove = (approval: Approval) => {
    approveRequest(approval.id, user?.name || '承認者');
    setSuccess(`${approval.referenceNumber}を承認しました`);
    setDetailOpen(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleRejectClick = (approval: Approval) => {
    setSelectedApproval(approval);
    setRejectReason('');
    setRejectOpen(true);
  };

  const handleRejectConfirm = () => {
    if (!selectedApproval || !rejectReason.trim()) return;
    rejectRequest(selectedApproval.id, user?.name || '承認者', rejectReason);
    setSuccess(`${selectedApproval.referenceNumber}を却下しました`);
    setRejectOpen(false);
    setDetailOpen(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  const pendingCount = approvals.filter((a) => a.status === 'pending').length;
  const approvedCount = approvals.filter((a) => a.status === 'approved').length;
  const rejectedCount = approvals.filter((a) => a.status === 'rejected').length;

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      {/* タブ */}
      <Paper sx={{ mb: 3 }}>
        <Tabs
          value={tabValue}
          onChange={(_, newValue) => {
            setTabValue(newValue);
            setPage(0);
          }}
          sx={{ borderBottom: 1, borderColor: 'divider' }}
        >
          <Tab
            label={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                承認待ち
                {pendingCount > 0 && (
                  <Chip label={pendingCount} size="small" color="warning" />
                )}
              </Box>
            }
          />
          <Tab
            label={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                承認済
                <Chip label={approvedCount} size="small" color="success" variant="outlined" />
              </Box>
            }
          />
          <Tab
            label={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                却下
                <Chip label={rejectedCount} size="small" color="error" variant="outlined" />
              </Box>
            }
          />
        </Tabs>
      </Paper>

      {/* テーブル */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ bgcolor: 'grey.100' }}>
              <TableCell sx={{ minWidth: 100 }}>種別</TableCell>
              <TableCell>申請番号</TableCell>
              <TableCell>タイトル</TableCell>
              <TableCell>申請者</TableCell>
              <TableCell>申請日</TableCell>
              <TableCell align="right">金額</TableCell>
              <TableCell align="center" sx={{ minWidth: 100 }}>ステータス</TableCell>
              <TableCell align="center">操作</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredApprovals.length > 0 ? (
              filteredApprovals
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((approval) => (
                  <TableRow key={approval.id} hover>
                    <TableCell>{getTypeChip(approval.type)}</TableCell>
                    <TableCell>
                      <Typography variant="body2" fontWeight="medium" color="primary">
                        {approval.referenceNumber}
                      </Typography>
                    </TableCell>
                    <TableCell>{approval.title}</TableCell>
                    <TableCell>{approval.requesterName}</TableCell>
                    <TableCell>{approval.requestDate}</TableCell>
                    <TableCell align="right">
                      {approval.amount ? `¥${approval.amount.toLocaleString()}` : '-'}
                    </TableCell>
                    <TableCell align="center">{getStatusChip(approval.status)}</TableCell>
                    <TableCell align="center">
                      <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center' }}>
                        <Button
                          size="small"
                          startIcon={<Visibility />}
                          onClick={() => handleViewDetail(approval)}
                          sx={buttonStyle}
                        >
                          詳細
                        </Button>
                        {canApprove && approval.status === 'pending' && (
                          <>
                            <Button
                              size="small"
                              variant="contained"
                              color="success"
                              startIcon={<CheckCircle />}
                              onClick={() => handleApprove(approval)}
                              sx={buttonStyle}
                            >
                              承認
                            </Button>
                            <Button
                              size="small"
                              variant="outlined"
                              color="error"
                              startIcon={<Cancel />}
                              onClick={() => handleRejectClick(approval)}
                              sx={buttonStyle}
                            >
                              却下
                            </Button>
                          </>
                        )}
                      </Box>
                    </TableCell>
                  </TableRow>
                ))
            ) : (
              <TableRow>
                <TableCell colSpan={8} align="center">
                  <Typography color="text.secondary" sx={{ py: 4 }}>
                    {tabValue === 0
                      ? '承認待ちの申請はありません'
                      : tabValue === 1
                      ? '承認済みの申請はありません'
                      : '却下された申請はありません'}
                  </Typography>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        {filteredApprovals.length > 0 && (
          <TablePagination
            component="div"
            count={filteredApprovals.length}
            page={page}
            onPageChange={(_, newPage) => setPage(newPage)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={(e) => {
              setRowsPerPage(parseInt(e.target.value, 10));
              setPage(0);
            }}
            labelRowsPerPage="表示件数:"
            labelDisplayedRows={({ from, to, count }) => `${from}-${to} / ${count}件`}
          />
        )}
      </TableContainer>

      {!canApprove && (
        <Alert severity="info" sx={{ mt: 2 }}>
          承認・却下は管理者または承認者のみ可能です
        </Alert>
      )}

      {/* 詳細ダイアログ */}
      <Dialog open={detailOpen} onClose={() => setDetailOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>申請詳細</DialogTitle>
        <DialogContent>
          {selectedApproval && (
            <Box sx={{ pt: 1 }}>
              <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                {getTypeChip(selectedApproval.type)}
                {getStatusChip(selectedApproval.status)}
              </Box>

              <Typography variant="body2" color="text.secondary">申請番号</Typography>
              <Typography fontWeight="medium" sx={{ mb: 2 }}>{selectedApproval.referenceNumber}</Typography>

              <Typography variant="body2" color="text.secondary">タイトル</Typography>
              <Typography fontWeight="medium" sx={{ mb: 2 }}>{selectedApproval.title}</Typography>

              <Typography variant="body2" color="text.secondary">申請者</Typography>
              <Typography sx={{ mb: 2 }}>{selectedApproval.requesterName}</Typography>

              <Typography variant="body2" color="text.secondary">申請日</Typography>
              <Typography sx={{ mb: 2 }}>{selectedApproval.requestDate}</Typography>

              {selectedApproval.amount && (
                <>
                  <Typography variant="body2" color="text.secondary">金額</Typography>
                  <Typography fontWeight="medium" color="primary" sx={{ mb: 2 }}>
                    ¥{selectedApproval.amount.toLocaleString()}
                  </Typography>
                </>
              )}

              {selectedApproval.note && (
                <>
                  <Typography variant="body2" color="text.secondary">備考</Typography>
                  <Typography sx={{ mb: 2 }}>{selectedApproval.note}</Typography>
                </>
              )}

              {selectedApproval.status === 'approved' && selectedApproval.approverName && (
                <>
                  <Typography variant="body2" color="text.secondary">承認者</Typography>
                  <Typography sx={{ mb: 2 }}>
                    {selectedApproval.approverName}（{selectedApproval.approvedDate}）
                  </Typography>
                </>
              )}

              {selectedApproval.status === 'rejected' && selectedApproval.rejectReason && (
                <>
                  <Typography variant="body2" color="text.secondary">却下理由</Typography>
                  <Typography color="error" sx={{ mb: 2 }}>{selectedApproval.rejectReason}</Typography>
                </>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDetailOpen(false)} sx={buttonStyle}>閉じる</Button>
          {canApprove && selectedApproval?.status === 'pending' && (
            <>
              <Button
                variant="outlined"
                color="error"
                startIcon={<Cancel />}
                onClick={() => handleRejectClick(selectedApproval)}
                sx={buttonStyle}
              >
                却下
              </Button>
              <Button
                variant="contained"
                color="success"
                startIcon={<CheckCircle />}
                onClick={() => handleApprove(selectedApproval)}
                sx={buttonStyle}
              >
                承認
              </Button>
            </>
          )}
        </DialogActions>
      </Dialog>

      {/* 却下理由ダイアログ */}
      <Dialog open={rejectOpen} onClose={() => setRejectOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>却下理由</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="却下理由"
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            multiline
            rows={3}
            required
            sx={{ mt: 1 }}
            placeholder="却下する理由を入力してください"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRejectOpen(false)} sx={buttonStyle}>キャンセル</Button>
          <Button
            variant="contained"
            color="error"
            onClick={handleRejectConfirm}
            disabled={!rejectReason.trim()}
            sx={buttonStyle}
          >
            却下する
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ApprovalListPage;
