import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  Button,
  Grid,
  Chip,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Stepper,
  Step,
  StepLabel,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
} from '@mui/material';
import {
  ArrowBack,
  Print,
  LocalShipping,
  Cancel,
} from '@mui/icons-material';
import usePurchaseStore from '../../store/purchaseStore';

type POStatus = 'draft' | 'pending' | 'approved' | 'partial' | 'completed' | 'cancelled';

const buttonStyle = {
  transition: 'all 0.3s ease',
  '&:hover': { transform: 'translateY(-2px)', boxShadow: 4 },
  minWidth: 120,
};

const PurchaseDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const order = usePurchaseStore((state) => state.getById(id || ''));
  const receiveItems = usePurchaseStore((state) => state.receiveItems);
  const cancelOrder = usePurchaseStore((state) => state.cancelOrder);

  const [receiveOpen, setReceiveOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [receivedQty, setReceivedQty] = useState<Record<string, number>>({});

  if (!order) {
    return (
      <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
        <Typography>発注情報が見つかりません</Typography>
        <Button onClick={() => navigate('/purchases')} sx={buttonStyle}>一覧に戻る</Button>
      </Box>
    );
  }

  const steps = ['下書き', '承認待ち', '承認済', '入荷完了'];
  const getActiveStep = (status: POStatus) => {
    switch (status) {
      case 'draft': return 0;
      case 'pending': return 1;
      case 'approved': return 2;
      case 'partial': return 2;
      case 'completed': return 4;
      case 'cancelled': return -1;
      default: return 0;
    }
  };

  const getStatusChip = (status: POStatus) => {
    const chipStyle = { minWidth: 90 };
    const statusConfig: Record<POStatus, { label: string; color: 'default' | 'primary' | 'warning' | 'success' | 'error' | 'info' }> = {
      draft: { label: '下書き', color: 'default' },
      pending: { label: '承認待ち', color: 'warning' },
      approved: { label: '承認済', color: 'primary' },
      partial: { label: '一部入荷', color: 'info' },
      completed: { label: '入荷完了', color: 'success' },
      cancelled: { label: 'キャンセル', color: 'error' },
    };
    const config = statusConfig[status];
    return <Chip label={config.label} color={config.color} sx={chipStyle} />;
  };

  const handleReceive = () => {
    receiveItems(order.id, receivedQty);
    setReceiveOpen(false);
    setReceivedQty({});
  };

  const handleCancel = () => {
    if (!cancelReason.trim()) return;
    cancelOrder(order.id, cancelReason);
    setCancelOpen(false);
    setCancelReason('');
  };

  const canReceive = order.status === 'approved' || order.status === 'partial';
  const canCancel = order.status !== 'completed' && order.status !== 'cancelled';

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {/* ヘッダー */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, gap: 2 }}>
        <IconButton 
          onClick={() => navigate('/purchases')}
          sx={{ transition: 'all 0.3s ease', '&:hover': { transform: 'translateX(-2px)' } }}
        >
          <ArrowBack />
        </IconButton>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" fontWeight="bold">
            {order.poNumber}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {order.supplierName}
          </Typography>
        </Box>
        {getStatusChip(order.status as POStatus)}
      </Box>

      {/* ステッパー */}
      {order.status !== 'cancelled' && (
        <Paper sx={{ p: 3, mb: 3 }}>
          <Stepper activeStep={getActiveStep(order.status as POStatus)} alternativeLabel>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
        </Paper>
      )}

      {/* アクションボタン - サイズ統一 */}
      <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
        <Button 
          variant="outlined" 
          startIcon={<Print />} 
          onClick={() => window.print()}
          sx={buttonStyle}
        >
          PDF出力
        </Button>
        {canReceive && (
          <Button
            variant="contained"
            startIcon={<LocalShipping />}
            onClick={() => setReceiveOpen(true)}
            color="success"
            sx={buttonStyle}
          >
            入荷登録
          </Button>
        )}
        {canCancel && (
          <Button
            variant="outlined"
            startIcon={<Cancel />}
            onClick={() => setCancelOpen(true)}
            color="error"
            sx={buttonStyle}
          >
            キャンセル
          </Button>
        )}
      </Box>

      <Grid container spacing={3}>
        {/* 発注情報 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              発注情報
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">発注日</Typography>
                <Typography fontWeight="medium">{order.orderDate}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">納期予定</Typography>
                <Typography fontWeight="medium">{order.expectedDeliveryDate}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">支払条件</Typography>
                <Typography fontWeight="medium">{order.paymentTerms || '-'}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">申請者</Typography>
                <Typography fontWeight="medium">{order.requesterName}</Typography>
              </Grid>
              {order.note && (
                <Grid item xs={12}>
                  <Typography color="text.secondary" variant="body2">備考</Typography>
                  <Typography>{order.note}</Typography>
                </Grid>
              )}
            </Grid>
          </Paper>
        </Grid>

        {/* 金額 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              金額
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography>小計</Typography>
              <Typography>¥{order.totalAmount.toLocaleString()}</Typography>
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography>消費税（10%）</Typography>
              <Typography>¥{order.taxAmount.toLocaleString()}</Typography>
            </Box>
            <Divider sx={{ my: 1 }} />
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="h6" fontWeight="bold">合計</Typography>
              <Typography variant="h6" fontWeight="bold" color="primary">
                ¥{order.grandTotal.toLocaleString()}
              </Typography>
            </Box>
          </Paper>
        </Grid>

        {/* 明細 */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              発注明細
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ bgcolor: 'grey.100' }}>
                    <TableCell>SKU</TableCell>
                    <TableCell>商品名</TableCell>
                    <TableCell align="right">単価</TableCell>
                    <TableCell align="right">数量</TableCell>
                    <TableCell align="right">入荷済</TableCell>
                    <TableCell align="right">小計</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {order.items.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.sku}</TableCell>
                      <TableCell>{item.productName}</TableCell>
                      <TableCell align="right">¥{item.unitPrice.toLocaleString()}</TableCell>
                      <TableCell align="right">{item.quantity}</TableCell>
                      <TableCell align="right">{item.receivedQuantity || 0}</TableCell>
                      <TableCell align="right">¥{item.subtotal.toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>

      {/* 入荷登録ダイアログ */}
      <Dialog open={receiveOpen} onClose={() => setReceiveOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>入荷登録</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            各商品の入荷数量を入力してください
          </Typography>
          {order.items.map((item) => {
            const remaining = item.quantity - (item.receivedQuantity || 0);
            return (
              <Box key={item.id} sx={{ mb: 2 }}>
                <Typography variant="body2">
                  {item.productName}（残: {remaining}）
                </Typography>
                <TextField
                  type="number"
                  size="small"
                  value={receivedQty[item.id] || ''}
                  onChange={(e) =>
                    setReceivedQty({
                      ...receivedQty,
                      [item.id]: Math.min(parseInt(e.target.value, 10) || 0, remaining),
                    })
                  }
                  inputProps={{ min: 0, max: remaining }}
                  fullWidth
                />
              </Box>
            );
          })}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setReceiveOpen(false)} sx={buttonStyle}>キャンセル</Button>
          <Button variant="contained" onClick={handleReceive} color="success" sx={buttonStyle}>
            入荷登録
          </Button>
        </DialogActions>
      </Dialog>

      {/* キャンセルダイアログ */}
      <Dialog open={cancelOpen} onClose={() => setCancelOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>発注キャンセル</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="キャンセル理由"
            value={cancelReason}
            onChange={(e) => setCancelReason(e.target.value)}
            multiline
            rows={3}
            required
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelOpen(false)} sx={buttonStyle}>戻る</Button>
          <Button
            variant="contained"
            onClick={handleCancel}
            color="error"
            disabled={!cancelReason.trim()}
            sx={buttonStyle}
          >
            キャンセル実行
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default PurchaseDetailPage;
