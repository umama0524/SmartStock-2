import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Autocomplete,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
} from '@mui/material';
import { ArrowBack, Add, Delete, Save, Send } from '@mui/icons-material';
import usePurchaseStore from '../../store/purchaseStore';
import useApprovalStore from '../../store/approvalStore';
import { useAuthStore } from '../../store/authStore';

const buttonStyle = {
  transition: 'box-shadow 0.2s ease',
  minWidth: 120,
  '&:hover': { boxShadow: 4 },
};

const mockSuppliers = [
  { id: '1', name: 'オフィス用品株式会社', contactPerson: '山田太郎', phone: '03-1234-5678' },
  { id: '2', name: '文具センター', contactPerson: '鈴木花子', phone: '03-2345-6789' },
  { id: '3', name: '事務機器販売', contactPerson: '佐藤一郎', phone: '03-3456-7890' },
];

const mockProducts = [
  { id: '1', sku: 'SKU-001', productName: 'A4用紙（500枚）', unitPrice: 250 },
  { id: '2', sku: 'SKU-045', productName: 'ボールペン（黒）', unitPrice: 80 },
  { id: '3', sku: 'SKU-089', productName: 'クリアファイル', unitPrice: 120 },
  { id: '4', sku: 'SKU-123', productName: 'ノート（B5）', unitPrice: 180 },
  { id: '5', sku: 'SKU-156', productName: 'ホッチキス', unitPrice: 450 },
  { id: '6', sku: 'SKU-201', productName: '付箋紙セット', unitPrice: 210 },
  { id: '7', sku: 'SKU-234', productName: 'マーカーペン（蛍光5色）', unitPrice: 320 },
  { id: '8', sku: 'SKU-267', productName: 'カッターナイフ', unitPrice: 150 },
];

interface OrderItem {
  id: string;
  productId: string;
  sku: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

const PurchaseCreatePage = () => {
  const navigate = useNavigate();
  const addOrder = usePurchaseStore((state) => state.addOrder);
  const addApproval = useApprovalStore((state) => state.addApproval);
  const user = useAuthStore((state) => state.user);

  const [supplier, setSupplier] = useState<typeof mockSuppliers[0] | null>(null);
  const [expectedDeliveryDate, setExpectedDeliveryDate] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('');
  const [note, setNote] = useState('');
  const [items, setItems] = useState<OrderItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<typeof mockProducts[0] | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const addItem = () => {
    if (!selectedProduct) return;

    const existingItem = items.find((item) => item.productId === selectedProduct.id);
    if (existingItem) {
      setItems(
        items.map((item) =>
          item.productId === selectedProduct.id
            ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.unitPrice }
            : item
        )
      );
    } else {
      setItems([
        ...items,
        {
          id: `item-${Date.now()}`,
          productId: selectedProduct.id,
          sku: selectedProduct.sku,
          productName: selectedProduct.productName,
          quantity: 1,
          unitPrice: selectedProduct.unitPrice,
          subtotal: selectedProduct.unitPrice,
        },
      ]);
    }
    setSelectedProduct(null);
  };

  const updateItemQuantity = (id: string, quantity: number) => {
    if (quantity < 1) return;
    setItems(
      items.map((item) =>
        item.id === id ? { ...item, quantity, subtotal: quantity * item.unitPrice } : item
      )
    );
  };

  const removeItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id));
  };

  const totalAmount = items.reduce((sum, item) => sum + item.subtotal, 0);
  const taxAmount = Math.floor(totalAmount * 0.1);
  const grandTotal = totalAmount + taxAmount;

  const handleSave = (submitForApproval: boolean) => {
    setError('');

    if (!supplier) {
      setError('サプライヤを選択してください');
      return;
    }
    if (!expectedDeliveryDate) {
      setError('納期予定日を入力してください');
      return;
    }
    if (items.length === 0) {
      setError('商品を追加してください');
      return;
    }

    const orderId = addOrder({
      supplierId: supplier.id,
      supplierName: supplier.name,
      orderDate: new Date().toISOString().split('T')[0],
      expectedDeliveryDate,
      status: submitForApproval ? 'pending' : 'draft',
      totalAmount,
      taxAmount,
      grandTotal,
      paymentTerms,
      note,
      items,
      requesterId: user?.id || '0',
      requesterName: user?.name || '不明',
    });

    if (submitForApproval) {
      addApproval({
        type: 'purchase',
        referenceId: orderId,
        referenceNumber: `PO-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}`,
        title: `${supplier.name}への発注`,
        requesterId: user?.id || '0',
        requesterName: user?.name || '不明',
        requestDate: new Date().toISOString().split('T')[0],
        status: 'pending',
        amount: grandTotal,
        itemCount: items.length,
        note,
      });
    }

    setSuccess(submitForApproval ? '承認申請しました' : '下書き保存しました');
    setTimeout(() => navigate('/purchases'), 1500);
  };

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {/* ヘッダー */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, gap: 2 }}>
        <IconButton 
          onClick={() => navigate('/purchases')}
          sx={{ transition: 'all 0.3s ease', '&:hover': { transform: 'translateX(-2px)' } }}
        >
          <ArrowBack />
        </IconButton>
        <Typography variant="h5" fontWeight="bold">
          新規発注作成
        </Typography>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Grid container spacing={3}>
        {/* 発注情報 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              発注情報
            </Typography>
            <Divider sx={{ mb: 2 }} />

            <Autocomplete
              options={mockSuppliers}
              getOptionLabel={(option) => option.name}
              value={supplier}
              onChange={(_, value) => setSupplier(value)}
              renderInput={(params) => (
                <TextField {...params} label="サプライヤ" required sx={{ mb: 2 }} />
              )}
            />

            <TextField
              fullWidth
              label="納期予定日"
              type="date"
              value={expectedDeliveryDate}
              onChange={(e) => setExpectedDeliveryDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              required
              sx={{ mb: 2 }}
            />

            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>支払条件</InputLabel>
              <Select
                value={paymentTerms}
                label="支払条件"
                onChange={(e) => setPaymentTerms(e.target.value)}
              >
                <MenuItem value="月末締め翌月末払い">月末締め翌月末払い</MenuItem>
                <MenuItem value="前払い">前払い</MenuItem>
                <MenuItem value="納品後30日">納品後30日</MenuItem>
              </Select>
            </FormControl>

            <TextField
              fullWidth
              label="備考"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              multiline
              rows={3}
            />
          </Paper>
        </Grid>

        {/* 金額サマリー */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              金額
            </Typography>
            <Divider sx={{ mb: 2 }} />

            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography>小計</Typography>
              <Typography>¥{totalAmount.toLocaleString()}</Typography>
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography>消費税（10%）</Typography>
              <Typography>¥{taxAmount.toLocaleString()}</Typography>
            </Box>
            <Divider sx={{ my: 1 }} />
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="h6" fontWeight="bold">
                合計
              </Typography>
              <Typography variant="h6" fontWeight="bold" color="primary">
                ¥{grandTotal.toLocaleString()}
              </Typography>
            </Box>
          </Paper>
        </Grid>

        {/* 商品追加 */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              商品
            </Typography>
            <Divider sx={{ mb: 2 }} />

            <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
              <Autocomplete
                options={mockProducts}
                getOptionLabel={(option) => `${option.sku} - ${option.productName}`}
                value={selectedProduct}
                onChange={(_, value) => setSelectedProduct(value)}
                renderInput={(params) => (
                  <TextField {...params} label="商品を検索" size="small" />
                )}
                sx={{ flex: 1 }}
              />
              <Button
                variant="contained"
                startIcon={<Add />}
                onClick={addItem}
                disabled={!selectedProduct}
                sx={buttonStyle}
              >
                追加
              </Button>
            </Box>

            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ bgcolor: 'grey.100' }}>
                    <TableCell>SKU</TableCell>
                    <TableCell>商品名</TableCell>
                    <TableCell align="right">単価</TableCell>
                    <TableCell align="center" width={120}>数量</TableCell>
                    <TableCell align="right">小計</TableCell>
                    <TableCell width={50}></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {items.length > 0 ? (
                    items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.sku}</TableCell>
                        <TableCell>{item.productName}</TableCell>
                        <TableCell align="right">¥{item.unitPrice.toLocaleString()}</TableCell>
                        <TableCell align="center">
                          <TextField
                            type="number"
                            size="small"
                            value={item.quantity}
                            onChange={(e) =>
                              updateItemQuantity(item.id, parseInt(e.target.value, 10) || 1)
                            }
                            inputProps={{ min: 1, style: { textAlign: 'center' } }}
                            sx={{ width: 80 }}
                          />
                        </TableCell>
                        <TableCell align="right">¥{item.subtotal.toLocaleString()}</TableCell>
                        <TableCell>
                          <IconButton 
                            size="small" 
                            onClick={() => removeItem(item.id)}
                            sx={{ transition: 'all 0.3s ease', '&:hover': { color: 'error.main' } }}
                          >
                            <Delete fontSize="small" />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} align="center">
                        <Typography color="text.secondary">商品を追加してください</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>

      {/* アクションボタン */}
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2, mt: 3 }}>
        <Button variant="outlined" onClick={() => navigate('/purchases')} sx={buttonStyle}>
          キャンセル
        </Button>
        <Button variant="outlined" startIcon={<Save />} onClick={() => handleSave(false)} sx={buttonStyle}>
          下書き保存
        </Button>
        <Button
          variant="contained"
          startIcon={<Send />}
          onClick={() => handleSave(true)}
          sx={{
            ...buttonStyle,
            bgcolor: 'primary.main',
            color: 'primary.contrastText',
            '&:hover': {
              boxShadow: 4,
              bgcolor: 'primary.dark',
            },
          }}
        >
          承認申請
        </Button>
      </Box>
    </Box>
  );
};

export default PurchaseCreatePage;
