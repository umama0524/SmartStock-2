import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  TextField,
  InputAdornment,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
} from '@mui/material';
import { Search, Add } from '@mui/icons-material';
import usePurchaseStore from '../../store/purchaseStore';

type POStatus = 'draft' | 'pending' | 'approved' | 'partial' | 'completed' | 'cancelled';

const buttonStyle = {
  transition: 'box-shadow 0.2s ease',
  '&:hover': {
    boxShadow: 4,
  },
};

const PurchaseListPage = () => {
  const navigate = useNavigate();
  const orders = usePurchaseStore((state) => state.orders);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const filteredOrders = useMemo(() => {
    return orders.filter((order) => {
      const matchesSearch =
        order.poNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.supplierName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [orders, searchQuery, statusFilter]);

  const getStatusChip = (status: POStatus) => {
    const chipStyle = { minWidth: 90, justifyContent: 'center' };
    const statusConfig: Record<POStatus, { label: string; color: 'default' | 'primary' | 'warning' | 'success' | 'error' | 'info' }> = {
      draft: { label: '下書き', color: 'default' },
      pending: { label: '承認待ち', color: 'warning' },
      approved: { label: '承認済', color: 'primary' },
      partial: { label: '一部入荷', color: 'info' },
      completed: { label: '入荷完了', color: 'success' },
      cancelled: { label: 'キャンセル', color: 'error' },
    };
    const config = statusConfig[status];
    return <Chip label={config.label} color={config.color} size="small" sx={chipStyle} />;
  };

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {/* フィルター */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
          <TextField
            placeholder="発注番号・サプライヤ名で検索"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            size="small"
            sx={{ minWidth: 300 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
          />
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <InputLabel>ステータス</InputLabel>
            <Select
              value={statusFilter}
              label="ステータス"
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <MenuItem value="all">すべて</MenuItem>
              <MenuItem value="draft">下書き</MenuItem>
              <MenuItem value="pending">承認待ち</MenuItem>
              <MenuItem value="approved">承認済</MenuItem>
              <MenuItem value="partial">一部入荷</MenuItem>
              <MenuItem value="completed">入荷完了</MenuItem>
              <MenuItem value="cancelled">キャンセル</MenuItem>
            </Select>
          </FormControl>
          <Box sx={{ flex: 1 }} />
          <Button
            variant="contained"
            startIcon={<Add />}
            onClick={() => navigate('/purchases/new')}
            sx={{
              ...buttonStyle,
              bgcolor: 'primary.main',
              color: 'primary.contrastText',
              '&:hover': {
                boxShadow: 4,
                bgcolor: 'primary.dark',
              },
            }}
          >
            新規発注
          </Button>
        </Box>
      </Paper>

      {/* テーブル */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ bgcolor: 'grey.100' }}>
              <TableCell>発注番号</TableCell>
              <TableCell>サプライヤ</TableCell>
              <TableCell>発注日</TableCell>
              <TableCell>納期予定</TableCell>
              <TableCell align="right">金額</TableCell>
              <TableCell align="center" sx={{ minWidth: 110 }}>ステータス</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredOrders
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((order) => (
                <TableRow
                  key={order.id}
                  hover
                  onClick={() => navigate(`/purchases/${order.id}`)}
                  sx={{ 
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                  }}
                >
                  <TableCell>
                    <Typography variant="body2" fontWeight="medium" color="primary">
                      {order.poNumber}
                    </Typography>
                  </TableCell>
                  <TableCell>{order.supplierName}</TableCell>
                  <TableCell>{order.orderDate}</TableCell>
                  <TableCell>{order.expectedDeliveryDate}</TableCell>
                  <TableCell align="right">
                    <Typography fontWeight="medium">
                      ¥{order.grandTotal.toLocaleString()}
                    </Typography>
                  </TableCell>
                  <TableCell align="center">{getStatusChip(order.status as POStatus)}</TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
        <TablePagination
          component="div"
          count={filteredOrders.length}
          page={page}
          onPageChange={(_, newPage) => setPage(newPage)}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
          labelRowsPerPage="表示件数:"
          labelDisplayedRows={({ from, to, count }) => `${from}-${to} / ${count}件`}
        />
      </TableContainer>
    </Box>
  );
};

export default PurchaseListPage;
