import { useState, useMemo } from 'react';
import {
  Box,
  Paper,
  Typography,
  Button,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  Alert,
} from '@mui/material';
import {
  ChevronLeft,
  ChevronRight,
  Add,
  Edit,
  Delete,
  Assignment,
  LocalShipping,
  Inventory,
  Event,
} from '@mui/icons-material';
import useCalendarStore from '../../store/calendarStore';
import { useAuthStore } from '../../store/authStore';

type EventType = 'instruction' | 'delivery' | 'shipment' | 'other';

interface CalendarEventData {
  id: string;
  date: string;
  title: string;
  description: string;
  type: EventType;
  createdBy: string;
  createdAt: string;
}

const CalendarPage = () => {
  const user = useAuthStore((state) => state.user);
  const events = useCalendarStore((state) => state.events) as CalendarEventData[];
  const addEvent = useCalendarStore((state) => state.addEvent);
  const updateEvent = useCalendarStore((state) => state.updateEvent);
  const deleteEvent = useCalendarStore((state) => state.deleteEvent);

  const canEdit = user?.role === 'admin';

  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CalendarEventData | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'instruction' as EventType,
  });
  const [success, setSuccess] = useState('');

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, month, 1).getDay();

  const monthNames = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];

  const calendarDays = useMemo(() => {
    const days: { date: string; day: number; isCurrentMonth: boolean }[] = [];

    const prevMonthDays = firstDayOfMonth;
    const prevMonth = month === 0 ? 11 : month - 1;
    const prevYear = month === 0 ? year - 1 : year;
    const daysInPrevMonth = new Date(prevYear, prevMonth + 1, 0).getDate();
    
    for (let i = prevMonthDays - 1; i >= 0; i--) {
      const day = daysInPrevMonth - i;
      days.push({
        date: `${prevYear}-${String(prevMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`,
        day,
        isCurrentMonth: false,
      });
    }

    for (let day = 1; day <= daysInMonth; day++) {
      days.push({
        date: `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`,
        day,
        isCurrentMonth: true,
      });
    }

    const remainingDays = 42 - days.length;
    const nextMonth = month === 11 ? 0 : month + 1;
    const nextYear = month === 11 ? year + 1 : year;
    for (let day = 1; day <= remainingDays; day++) {
      days.push({
        date: `${nextYear}-${String(nextMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`,
        day,
        isCurrentMonth: false,
      });
    }

    return days;
  }, [year, month, daysInMonth, firstDayOfMonth]);

  const getEventIcon = (type: EventType) => {
    switch (type) {
      case 'instruction': return <Assignment color="primary" />;
      case 'delivery': return <Inventory color="success" />;
      case 'shipment': return <LocalShipping color="warning" />;
      default: return <Event color="info" />;
    }
  };

  const getEventColor = (type: EventType): 'primary' | 'success' | 'warning' | 'info' => {
    switch (type) {
      case 'instruction': return 'primary';
      case 'delivery': return 'success';
      case 'shipment': return 'warning';
      default: return 'info';
    }
  };

  const handleAddEvent = () => {
    if (!selectedDate) return;
    setEditingEvent(null);
    setFormData({ title: '', description: '', type: 'instruction' });
    setDialogOpen(true);
  };

  const handleEditEvent = (event: CalendarEventData) => {
    setEditingEvent(event);
    setFormData({
      title: event.title,
      description: event.description,
      type: event.type,
    });
    setDialogOpen(true);
  };

  const handleDeleteEvent = (id: string) => {
    deleteEvent(id);
    setSuccess('予定を削除しました');
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleSaveEvent = () => {
    if (!formData.title.trim()) return;

    if (editingEvent) {
      updateEvent(editingEvent.id, formData);
      setSuccess('予定を更新しました');
    } else if (selectedDate) {
      addEvent({
        date: selectedDate,
        title: formData.title,
        description: formData.description,
        type: formData.type,
        createdBy: user?.name || '不明',
      });
      setSuccess('予定を追加しました');
    }

    setDialogOpen(false);
    setTimeout(() => setSuccess(''), 3000);
  };

  const selectedDateEvents = selectedDate
    ? events.filter((e) => e.date === selectedDate)
    : [];
  const today = new Date().toISOString().split('T')[0];

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Box sx={{ display: 'flex', gap: 3, flexWrap: 'wrap' }}>
        {/* カレンダー */}
        <Box sx={{ flex: '1 1 600px', minWidth: 300 }}>
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
              <IconButton onClick={() => setCurrentDate(new Date(year, month - 1, 1))}>
                <ChevronLeft />
              </IconButton>
              <Typography variant="h5" fontWeight="bold">
                {year}年 {monthNames[month]}
              </Typography>
              <IconButton onClick={() => setCurrentDate(new Date(year, month + 1, 1))}>
                <ChevronRight />
              </IconButton>
            </Box>

            {/* 曜日ヘッダー */}
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', mb: 1 }}>
              {['日', '月', '火', '水', '木', '金', '土'].map((day, index) => (
                <Typography
                  key={day}
                  align="center"
                  fontWeight="bold"
                  sx={{
                    color: index === 0 ? 'error.main' : index === 6 ? 'primary.main' : 'text.primary'
                  }}
                >
                  {day}
                </Typography>
              ))}
            </Box>

            {/* カレンダー日付 */}
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)' }}>
              {calendarDays.map((dayInfo, index) => {
                const dayEvents = events.filter((e) => e.date === dayInfo.date);
                const isToday = dayInfo.date === today;
                const isSelected = dayInfo.date === selectedDate;
                const dayOfWeek = index % 7;

                let textColor = 'text.primary';
                if (dayOfWeek === 0) textColor = 'error.main';
                if (dayOfWeek === 6) textColor = 'primary.main';

                return (
                  <Box
                    key={dayInfo.date}
                    onClick={() => setSelectedDate(dayInfo.date)}
                    sx={{
                      p: 1,
                      minHeight: 80,
                      border: '1px solid',
                      borderColor: isSelected ? 'primary.main' : 'grey.200',
                      bgcolor: isSelected ? 'primary.50' : isToday ? 'grey.100' : 'transparent',
                      cursor: 'pointer',
                      opacity: dayInfo.isCurrentMonth ? 1 : 0.4,
                      '&:hover': { bgcolor: 'action.hover' },
                    }}
                  >
                    <Typography
                      fontWeight={isToday ? 'bold' : 'normal'}
                      sx={{ color: textColor }}
                    >
                      {dayInfo.day}
                    </Typography>
                    {dayEvents.slice(0, 2).map((event) => (
                      <Chip
                        key={event.id}
                        label={event.title}
                        size="small"
                        color={getEventColor(event.type)}
                        sx={{ mt: 0.5, maxWidth: '100%', fontSize: 10 }}
                      />
                    ))}
                    {dayEvents.length > 2 && (
                      <Typography variant="caption" color="text.secondary">
                        +{dayEvents.length - 2}件
                      </Typography>
                    )}
                  </Box>
                );
              })}
            </Box>
          </Paper>
        </Box>

        {/* 予定詳細 */}
        <Box sx={{ flex: '1 1 300px', minWidth: 280 }}>
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
              <Typography variant="h6" fontWeight="bold">
                {selectedDate ? `${selectedDate.split('-')[1]}月${selectedDate.split('-')[2]}日の予定` : '日付を選択'}
              </Typography>
              {canEdit && selectedDate && (
                <Button variant="contained" size="small" startIcon={<Add />} onClick={handleAddEvent}>
                  追加
                </Button>
              )}
            </Box>
            <Divider sx={{ mb: 2 }} />

            {selectedDate ? (
              selectedDateEvents.length > 0 ? (
                <List>
                  {selectedDateEvents.map((event) => (
                    <ListItem
                      key={event.id}
                      sx={{ bgcolor: 'grey.50', borderRadius: 2, mb: 1, flexDirection: 'column', alignItems: 'flex-start' }}
                    >
                      <Box sx={{ display: 'flex', alignItems: 'center', width: '100%', mb: 1 }}>
                        <ListItemIcon sx={{ minWidth: 36 }}>{getEventIcon(event.type)}</ListItemIcon>
                        <ListItemText 
                          primary={event.title} 
                          slotProps={{
                            primary: { fontWeight: 'medium' }
                          }}
                        />
                        {canEdit && (
                          <>
                            <IconButton size="small" onClick={() => handleEditEvent(event)}>
                              <Edit fontSize="small" />
                            </IconButton>
                            <IconButton size="small" color="error" onClick={() => handleDeleteEvent(event.id)}>
                              <Delete fontSize="small" />
                            </IconButton>
                          </>
                        )}
                      </Box>
                      {event.description && (
                        <Typography variant="body2" color="text.secondary" sx={{ ml: 4.5 }}>
                          {event.description}
                        </Typography>
                      )}
                    </ListItem>
                  ))}
                </List>
              ) : (
                <Typography color="text.secondary" textAlign="center" sx={{ py: 4 }}>
                  この日の予定はありません
                </Typography>
              )
            ) : (
              <Typography color="text.secondary" textAlign="center" sx={{ py: 4 }}>
                カレンダーから日付を選択
              </Typography>
            )}

            <Box sx={{ mt: 3 }}>
              <Typography variant="subtitle2" fontWeight="bold" sx={{ mb: 1 }}>種別</Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                <Chip icon={<Assignment />} label="業務指示" size="small" color="primary" variant="outlined" />
                <Chip icon={<Inventory />} label="入荷予定" size="small" color="success" variant="outlined" />
                <Chip icon={<LocalShipping />} label="出荷予定" size="small" color="warning" variant="outlined" />
                <Chip icon={<Event />} label="その他" size="small" color="info" variant="outlined" />
              </Box>
            </Box>

            {!canEdit && (
              <Alert severity="info" sx={{ mt: 3 }}>
                予定の追加・編集は管理者のみ可能です
              </Alert>
            )}
          </Paper>
        </Box>
      </Box>

      {/* ダイアログ */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{editingEvent ? '予定を編集' : '予定を追加'}</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="タイトル"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            sx={{ mt: 1, mb: 2 }}
            required
          />
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>種別</InputLabel>
            <Select
              value={formData.type}
              label="種別"
              onChange={(e) => setFormData({ ...formData, type: e.target.value as EventType })}
            >
              <MenuItem value="instruction">業務指示</MenuItem>
              <MenuItem value="delivery">入荷予定</MenuItem>
              <MenuItem value="shipment">出荷予定</MenuItem>
              <MenuItem value="other">その他</MenuItem>
            </Select>
          </FormControl>
          <TextField
            fullWidth
            label="詳細"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            multiline
            rows={3}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>キャンセル</Button>
          <Button variant="contained" onClick={handleSaveEvent} disabled={!formData.title.trim()}>
            保存
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default CalendarPage;
