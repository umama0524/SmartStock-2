import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  Button,
  Grid,
  Chip,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  LinearProgress,
  Card,
  CardContent,
  IconButton,
} from '@mui/material';
import {
  ArrowBack,
  Add,
  Remove,
  SwapVert,
  Warning,
  Error as ErrorIcon,
  CheckCircle,
  TrendingUp,
  TrendingDown,
} from '@mui/icons-material';
import useInventoryStore from '../../store/inventoryStore';
import InboundModal from './InboundModal';
import OutboundModal from './OutboundModal';
import AdjustmentModal from './AdjustmentModal';

// 共通ボタンスタイル
// Buttons should feel responsive without excessive motion. We remove
// vertical translation on hover and instead apply a subtle shadow to
// indicate interactivity.
const buttonStyle = {
  transition: 'box-shadow 0.2s ease',
  '&:hover': { boxShadow: 4 },
};

// 共通カードスタイル
const cardStyle = {
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
};

const InventoryDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const inventory = useInventoryStore((state) => state.getById(id || ''));
  const transactions = useInventoryStore((state) => state.getTransactions(id || ''));

  const [inboundOpen, setInboundOpen] = useState(false);
  const [outboundOpen, setOutboundOpen] = useState(false);
  const [adjustmentOpen, setAdjustmentOpen] = useState(false);

  if (!inventory) {
    return (
      <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
        <Typography>在庫情報が見つかりません</Typography>
        <Button onClick={() => navigate('/inventory')} sx={buttonStyle}>一覧に戻る</Button>
      </Box>
    );
  }

  const getStatusChip = (status: string) => {
    const chipStyle = { minWidth: 80 };
    switch (status) {
      case 'critical':
        return <Chip icon={<ErrorIcon />} label="危険" color="error" sx={chipStyle} />;
      case 'low':
        return <Chip icon={<Warning />} label="低在庫" color="warning" sx={chipStyle} />;
      case 'normal':
        return <Chip icon={<CheckCircle />} label="正常" color="success" sx={chipStyle} />;
      default:
        return <Chip label={status} sx={chipStyle} />;
    }
  };

  const stockPercentage = Math.min(
    (inventory.quantity / (inventory.reorderPoint * 2)) * 100,
    100
  );

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {/* ヘッダー */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, gap: 2 }}>
        <IconButton
          onClick={() => navigate('/inventory')}
          sx={{
            transition: 'color 0.2s ease',
            color: 'text.primary',
            '&:hover': {
              color: 'primary.main',
            },
          }}
        >
          <ArrowBack />
        </IconButton>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" fontWeight="bold">
            {inventory.productName}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {inventory.sku}
          </Typography>
        </Box>
        {getStatusChip(inventory.status)}
      </Box>

      {/* アクションボタン */}
      <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => setInboundOpen(true)}
          sx={{
            ...buttonStyle,
            bgcolor: 'success.main',
            color: 'success.contrastText',
            minWidth: 120,
            '&:hover': {
              boxShadow: 4,
              bgcolor: 'success.dark',
            },
          }}
        >
          入庫登録
        </Button>
        <Button
          variant="contained"
          startIcon={<Remove />}
          onClick={() => setOutboundOpen(true)}
          sx={{
            ...buttonStyle,
            bgcolor: 'warning.main',
            color: 'warning.contrastText',
            minWidth: 120,
            '&:hover': {
              boxShadow: 4,
              bgcolor: 'warning.dark',
            },
          }}
        >
          出庫登録
        </Button>
        <Button
          variant="contained"
          startIcon={<SwapVert />}
          onClick={() => setAdjustmentOpen(true)}
          sx={{
            ...buttonStyle,
            bgcolor: 'primary.main',
            color: 'primary.contrastText',
            minWidth: 120,
            '&:hover': {
              boxShadow: 4,
              bgcolor: 'primary.dark',
            },
          }}
        >
          在庫調整
        </Button>
      </Box>

      <Grid container spacing={3}>
        {/* 在庫サマリー - 高さ統一 */}
        <Grid item xs={12} md={4}>
          <Card sx={cardStyle}>
            <CardContent sx={{ textAlign: 'center', py: 3 }}>
              <Typography color="text.secondary" gutterBottom>
                現在庫数
              </Typography>
              <Typography variant="h3" fontWeight="bold" color="primary">
                {inventory.quantity.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                単位: 個
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={cardStyle}>
            <CardContent sx={{ textAlign: 'center', py: 3 }}>
              <Typography color="text.secondary" gutterBottom>
                引当数
              </Typography>
              <Typography variant="h3" fontWeight="bold" color="warning.main">
                {inventory.reservedQuantity.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                受注引当分
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card sx={cardStyle}>
            <CardContent sx={{ textAlign: 'center', py: 3 }}>
              <Typography color="text.secondary" gutterBottom>
                有効在庫
              </Typography>
              <Typography variant="h3" fontWeight="bold" color="success.main">
                {inventory.availableQuantity.toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                出荷可能数
              </Typography>
            </CardContent>
          </Card>
        </Grid>

        {/* 基本情報と在庫レベル - 高さ統一 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              基本情報
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">
                  SKU
                </Typography>
                <Typography fontWeight="medium">{inventory.sku}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">
                  保管場所
                </Typography>
                <Typography fontWeight="medium">{inventory.location}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">
                  単価
                </Typography>
                <Typography fontWeight="medium">
                  ¥{inventory.unitPrice.toLocaleString()}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">
                  最終更新
                </Typography>
                <Typography fontWeight="medium">{inventory.lastUpdated}</Typography>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              在庫レベル
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Box sx={{ mb: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2">現在庫</Typography>
                <Typography variant="body2" fontWeight="medium">
                  {inventory.quantity} / {inventory.reorderPoint * 2}
                </Typography>
              </Box>
              <LinearProgress
                variant="determinate"
                value={stockPercentage}
                color={
                  inventory.status === 'critical'
                    ? 'error'
                    : inventory.status === 'low'
                    ? 'warning'
                    : 'success'
                }
                sx={{ height: 10, borderRadius: 5 }}
              />
            </Box>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">
                  発注点
                </Typography>
                <Typography fontWeight="medium" color="warning.main">
                  {inventory.reorderPoint.toLocaleString()}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">
                  安全在庫
                </Typography>
                <Typography fontWeight="medium" color="error.main">
                  {inventory.safetyStock.toLocaleString()}
                </Typography>
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        {/* 入出庫履歴 */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              入出庫履歴
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ bgcolor: 'grey.100' }}>
                    <TableCell>日時</TableCell>
                    <TableCell>種別</TableCell>
                    <TableCell align="right">数量</TableCell>
                    <TableCell align="right">残高</TableCell>
                    <TableCell>理由</TableCell>
                    <TableCell>担当者</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {transactions.length > 0 ? (
                    transactions.map((tx) => (
                      <TableRow key={tx.id}>
                        <TableCell>{tx.date}</TableCell>
                        <TableCell>
                          <Chip
                            label={tx.type}
                            size="small"
                            color={
                              tx.type === '入庫'
                                ? 'success'
                                : tx.type === '出庫'
                                ? 'warning'
                                : 'default'
                            }
                            sx={{ minWidth: 60 }}
                          />
                        </TableCell>
                        <TableCell align="right">
                          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 0.5 }}>
                            {tx.quantity > 0 ? (
                              <TrendingUp color="success" fontSize="small" />
                            ) : (
                              <TrendingDown color="error" fontSize="small" />
                            )}
                            <Typography
                              color={tx.quantity > 0 ? 'success.main' : 'error.main'}
                              fontWeight="medium"
                            >
                              {tx.quantity > 0 ? '+' : ''}{tx.quantity}
                            </Typography>
                          </Box>
                        </TableCell>
                        <TableCell align="right">{tx.balance}</TableCell>
                        <TableCell>{tx.reason}</TableCell>
                        <TableCell>{tx.user}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} align="center">
                        <Typography color="text.secondary">履歴がありません</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>

      {/* モーダル */}
      <InboundModal
        open={inboundOpen}
        onClose={() => setInboundOpen(false)}
        inventory={inventory}
      />
      <OutboundModal
        open={outboundOpen}
        onClose={() => setOutboundOpen(false)}
        inventory={inventory}
      />
      <AdjustmentModal
        open={adjustmentOpen}
        onClose={() => setAdjustmentOpen(false)}
        inventory={inventory}
      />
    </Box>
  );
};

export default InventoryDetailPage;
