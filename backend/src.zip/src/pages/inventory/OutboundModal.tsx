import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box,
  Typography,
  Alert,
  Divider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from '@mui/material';
import { Remove, Warning } from '@mui/icons-material';
import useInventoryStore from '../../store/inventoryStore';
import { useAuthStore } from '../../store/authStore';

const buttonStyle = {
  transition: 'box-shadow 0.2s ease',
  minWidth: 100,
  '&:hover': {
    boxShadow: 4,
  },
};

interface InventoryItem {
  id: string;
  sku: string;
  productName: string;
  quantity: number;
  availableQuantity: number;
  safetyStock: number;
}

interface OutboundModalProps {
  open: boolean;
  onClose: () => void;
  inventory: InventoryItem;
}

const outboundReasons = [
  '販売出荷',
  'サンプル出荷',
  '返品処理',
  '廃棄処分',
  'その他',
];

const OutboundModal = ({ open, onClose, inventory }: OutboundModalProps) => {
  const outbound = useInventoryStore((state) => state.outbound);
  const user = useAuthStore((state) => state.user);

  const [quantity, setQuantity] = useState('');
  const [reason, setReason] = useState('販売出荷');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');

  const handleClose = () => {
    setQuantity('');
    setReason('販売出荷');
    setNote('');
    setError('');
    onClose();
  };

  const handleSubmit = () => {
    setError('');

    const qty = parseInt(quantity, 10);
    if (!qty || qty <= 0) {
      setError('出庫数量を正しく入力してください');
      return;
    }

    if (qty > inventory.availableQuantity) {
      setError(`有効在庫（${inventory.availableQuantity}）を超える出庫はできません`);
      return;
    }

    // 出庫処理を実行
    outbound(
      inventory.id,
      qty,
      reason,
      note || '',
      user?.name || '在庫担当'
    );

    handleClose();
  };

  const qty = parseInt(quantity, 10) || 0;
  const newQuantity = inventory.quantity - qty;
  const isOverStock = qty > inventory.availableQuantity;
  const isBelowSafety = newQuantity < inventory.safetyStock && newQuantity >= 0;

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Remove color="warning" />
          出庫登録
        </Box>
      </DialogTitle>
      <DialogContent>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <Box sx={{ bgcolor: 'grey.50', p: 2, borderRadius: 2, mb: 3 }}>
          <Typography variant="body2" color="text.secondary">対象商品</Typography>
          <Typography fontWeight="bold">{inventory.productName}</Typography>
          <Typography variant="body2" color="text.secondary">{inventory.sku}</Typography>
          <Box sx={{ display: 'flex', gap: 2, mt: 1 }}>
            <Typography variant="body2">
              現在庫: <strong>{inventory.quantity}</strong>
            </Typography>
            <Typography variant="body2">
              有効在庫: <strong>{inventory.availableQuantity}</strong>
            </Typography>
          </Box>
        </Box>

        <TextField
          fullWidth
          label="出庫数量"
          type="number"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          inputProps={{ min: 1, max: inventory.availableQuantity }}
          required
          error={isOverStock}
          helperText={isOverStock ? '有効在庫を超えています' : ''}
          sx={{ mb: 2 }}
        />

        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel>出庫理由</InputLabel>
          <Select
            value={reason}
            label="出庫理由"
            onChange={(e) => setReason(e.target.value)}
          >
            {outboundReasons.map((r) => (
              <MenuItem key={r} value={r}>{r}</MenuItem>
            ))}
          </Select>
        </FormControl>

        <TextField
          fullWidth
          label="備考（任意）"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          multiline
          rows={2}
          sx={{ mb: 2 }}
        />

        {isBelowSafety && (
          <Alert severity="warning" icon={<Warning />} sx={{ mb: 2 }}>
            出庫後の在庫数が安全在庫（{inventory.safetyStock}）を下回ります
          </Alert>
        )}

        <Divider sx={{ my: 2 }} />

        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography color="text.secondary">現在庫数</Typography>
          <Typography fontWeight="medium">{inventory.quantity}</Typography>
        </Box>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
          <Typography color="text.secondary">出庫後</Typography>
          <Typography
            variant="h6"
            fontWeight="bold"
            color={isOverStock ? 'error.main' : isBelowSafety ? 'warning.main' : 'text.primary'}
          >
            {newQuantity}
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} sx={{ ...buttonStyle, color: 'text.primary' }}>キャンセル</Button>
        <Button
          variant="contained"
          color="warning"
          onClick={handleSubmit}
          disabled={!quantity || qty <= 0 || isOverStock}
          sx={{
            ...buttonStyle,
            bgcolor: 'warning.main',
            color: 'warning.contrastText',
            '&:hover': {
              boxShadow: 4,
              bgcolor: 'warning.dark',
            },
          }}
        >
          出庫登録
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default OutboundModal;
