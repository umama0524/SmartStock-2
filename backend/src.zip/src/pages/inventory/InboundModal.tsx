import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box,
  Typography,
  Alert,
  Divider,
} from '@mui/material';
import { Add } from '@mui/icons-material';
import useInventoryStore from '../../store/inventoryStore';
import { useAuthStore } from '../../store/authStore';

const buttonStyle = {
  transition: 'box-shadow 0.2s ease',
  minWidth: 100,
  '&:hover': {
    boxShadow: 4,
  },
};

interface InventoryItem {
  id: string;
  sku: string;
  productName: string;
  quantity: number;
}

interface InboundModalProps {
  open: boolean;
  onClose: () => void;
  inventory: InventoryItem;
}

const InboundModal = ({ open, onClose, inventory }: InboundModalProps) => {
  const inbound = useInventoryStore((state) => state.inbound);
  const user = useAuthStore((state) => state.user);

  const [quantity, setQuantity] = useState('');
  const [lotNumber, setLotNumber] = useState('');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');

  const handleClose = () => {
    setQuantity('');
    setLotNumber('');
    setNote('');
    setError('');
    onClose();
  };

  const handleSubmit = () => {
    setError('');

    const qty = parseInt(quantity, 10);
    if (!qty || qty <= 0) {
      setError('入庫数量を正しく入力してください');
      return;
    }

    // 入庫処理を実行
    inbound(
      inventory.id,
      qty,
      lotNumber || '',
      note || '',
      user?.name || '在庫担当'
    );

    handleClose();
  };

  const newQuantity = inventory.quantity + (parseInt(quantity, 10) || 0);

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Add color="success" />
          入庫登録
        </Box>
      </DialogTitle>
      <DialogContent>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <Box sx={{ bgcolor: 'grey.50', p: 2, borderRadius: 2, mb: 3 }}>
          <Typography variant="body2" color="text.secondary">対象商品</Typography>
          <Typography fontWeight="bold">{inventory.productName}</Typography>
          <Typography variant="body2" color="text.secondary">{inventory.sku}</Typography>
        </Box>

        <TextField
          fullWidth
          label="入庫数量"
          type="number"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          inputProps={{ min: 1 }}
          required
          sx={{ mb: 2 }}
        />

        <TextField
          fullWidth
          label="ロット番号（任意）"
          value={lotNumber}
          onChange={(e) => setLotNumber(e.target.value)}
          sx={{ mb: 2 }}
          placeholder="例: LOT-2025-001"
        />

        <TextField
          fullWidth
          label="備考（任意）"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          multiline
          rows={2}
          sx={{ mb: 2 }}
        />

        <Divider sx={{ my: 2 }} />

        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography color="text.secondary">現在庫数</Typography>
          <Typography fontWeight="medium">{inventory.quantity}</Typography>
        </Box>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
          <Typography color="text.secondary">入庫後</Typography>
          <Typography variant="h6" fontWeight="bold" color="success.main">
            {newQuantity}
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} sx={{ ...buttonStyle, color: 'text.primary' }}>キャンセル</Button>
        <Button
          variant="contained"
          color="success"
          onClick={handleSubmit}
          disabled={!quantity || parseInt(quantity, 10) <= 0}
          sx={{ ...buttonStyle, bgcolor: 'success.main', color: 'success.contrastText', '&:hover': { boxShadow: 4, bgcolor: 'success.dark' } }}
        >
          入庫登録
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default InboundModal;
