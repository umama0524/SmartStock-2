import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  TextField,
  InputAdornment,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Tooltip,
  Typography,
} from '@mui/material';
import {
  Search,
  FileDownload,
  Refresh,
  Warning,
  Error as ErrorIcon,
  CheckCircle,
} from '@mui/icons-material';
import useInventoryStore from '../../store/inventoryStore';

const InventoryListPage = () => {
  const navigate = useNavigate();
  const inventory = useInventoryStore((state) => state.inventory);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const filteredInventory = useMemo(() => {
    return inventory.filter((item) => {
      const matchesSearch =
        item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.productName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [inventory, searchQuery, statusFilter]);

  const getStatusChip = (status: string) => {
    const chipStyle = { minWidth: 80, justifyContent: 'center' };
    switch (status) {
      case 'critical':
        return <Chip icon={<ErrorIcon />} label="危険" color="error" size="small" sx={chipStyle} />;
      case 'low':
        return <Chip icon={<Warning />} label="低在庫" color="warning" size="small" sx={chipStyle} />;
      case 'normal':
        return <Chip icon={<CheckCircle />} label="正常" color="success" size="small" sx={chipStyle} />;
      case 'excess':
        return <Chip label="過剰" color="info" size="small" sx={chipStyle} />;
      default:
        return <Chip label={status} size="small" sx={chipStyle} />;
    }
  };

  const handleRowClick = (id: string) => {
    navigate(`/inventory/${id}`);
  };

  const handleExportCSV = () => {
    const headers = ['SKU', '商品名', '現在庫', '引当数', '有効在庫', 'ステータス', '保管場所', '最終更新'];
    const csvData = filteredInventory.map((item) => [
      item.sku,
      item.productName,
      item.quantity,
      item.reservedQuantity,
      item.availableQuantity,
      item.status === 'critical' ? '危険' : item.status === 'low' ? '低在庫' : item.status === 'normal' ? '正常' : '過剰',
      item.location,
      item.lastUpdated,
    ]);

    const csvContent = [headers, ...csvData]
      .map((row) => row.map((cell) => `"${cell}"`).join(','))
      .join('\n');

    const bom = '\uFEFF';
    const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `在庫一覧_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {/* フィルター */}
      <Paper sx={{ p: 2, mb: 3 }}>
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
          <TextField
            placeholder="SKU・商品名で検索"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            size="small"
            sx={{ minWidth: 300 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search />
                </InputAdornment>
              ),
            }}
          />
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <InputLabel>ステータス</InputLabel>
            <Select
              value={statusFilter}
              label="ステータス"
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <MenuItem value="all">すべて</MenuItem>
              <MenuItem value="critical">危険</MenuItem>
              <MenuItem value="low">低在庫</MenuItem>
              <MenuItem value="normal">正常</MenuItem>
              <MenuItem value="excess">過剰</MenuItem>
            </Select>
          </FormControl>
          <Box sx={{ flex: 1 }} />
          <Button
            variant="outlined"
            color="primary"
            startIcon={<FileDownload />}
            onClick={handleExportCSV}
            sx={{
              transition: 'box-shadow 0.2s ease',
              '&:hover': {
                boxShadow: 2,
              },
            }}
          >
            CSV出力
          </Button>
          <Tooltip title="更新">
            <IconButton
              sx={{
                color: 'text.secondary',
                transition: 'transform 0.3s ease, color 0.2s ease',
                '&:hover': {
                  transform: 'rotate(180deg)',
                  color: 'primary.main',
                },
              }}
            >
              <Refresh />
            </IconButton>
          </Tooltip>
        </Box>
      </Paper>

      {/* テーブル */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ bgcolor: 'grey.100' }}>
              <TableCell>SKU</TableCell>
              <TableCell>商品名</TableCell>
              <TableCell align="right">現在庫</TableCell>
              <TableCell align="right">引当数</TableCell>
              <TableCell align="right">有効在庫</TableCell>
              <TableCell align="center" sx={{ minWidth: 100 }}>ステータス</TableCell>
              <TableCell>保管場所</TableCell>
              <TableCell>最終更新</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredInventory
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row) => (
                <TableRow
                  key={row.id}
                  hover
                  onClick={() => handleRowClick(row.id)}
                  sx={{ 
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    '&:hover': { bgcolor: 'action.hover' },
                  }}
                >
                  <TableCell>
                    <Typography variant="body2" fontWeight="medium" color="primary">
                      {row.sku}
                    </Typography>
                  </TableCell>
                  <TableCell>{row.productName}</TableCell>
                  <TableCell align="right">{row.quantity.toLocaleString()}</TableCell>
                  <TableCell align="right">{row.reservedQuantity.toLocaleString()}</TableCell>
                  <TableCell align="right">
                    <Typography fontWeight="medium">{row.availableQuantity.toLocaleString()}</Typography>
                  </TableCell>
                  <TableCell align="center">{getStatusChip(row.status)}</TableCell>
                  <TableCell>{row.location}</TableCell>
                  <TableCell>
                    <Typography variant="body2" color="text.secondary">
                      {row.lastUpdated}
                    </Typography>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
        <TablePagination
          component="div"
          count={filteredInventory.length}
          page={page}
          onPageChange={(_, newPage) => setPage(newPage)}
          rowsPerPage={rowsPerPage}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
          labelRowsPerPage="表示件数:"
          labelDisplayedRows={({ from, to, count }) => `${from}-${to} / ${count}件`}
        />
      </TableContainer>
    </Box>
  );
};

export default InventoryListPage;
