import { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box,
  Typography,
  Alert,
  Divider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import { SwapVert, Add, Remove } from '@mui/icons-material';
import useInventoryStore from '../../store/inventoryStore';
import { useAuthStore } from '../../store/authStore';

const buttonStyle = {
  transition: 'box-shadow 0.2s ease',
  minWidth: 100,
  '&:hover': {
    boxShadow: 4,
  },
};

interface InventoryItem {
  id: string;
  sku: string;
  productName: string;
  quantity: number;
}

interface AdjustmentModalProps {
  open: boolean;
  onClose: () => void;
  inventory: InventoryItem;
}

const adjustmentReasons = [
  { value: 'damaged', label: '破損' },
  { value: 'expired', label: '期限切れ' },
  { value: 'lost', label: '紛失' },
  { value: 'found', label: '発見' },
  { value: 'count_diff', label: '棚卸差異' },
  { value: 'other', label: 'その他' },
];

const AdjustmentModal = ({ open, onClose, inventory }: AdjustmentModalProps) => {
  const adjust = useInventoryStore((state) => state.adjust);
  const user = useAuthStore((state) => state.user);

  const [adjustType, setAdjustType] = useState<'increase' | 'decrease'>('decrease');
  const [quantity, setQuantity] = useState('');
  const [reasonCode, setReasonCode] = useState('count_diff');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');

  const handleClose = () => {
    setAdjustType('decrease');
    setQuantity('');
    setReasonCode('count_diff');
    setNote('');
    setError('');
    onClose();
  };

  const handleSubmit = () => {
    setError('');

    const qty = parseInt(quantity, 10);
    if (!qty || qty <= 0) {
      setError('調整数量を正しく入力してください');
      return;
    }

    if (reasonCode === 'other' && !note.trim()) {
      setError('「その他」を選択した場合は備考を入力してください');
      return;
    }

    if (adjustType === 'decrease' && qty > inventory.quantity) {
      setError(`現在庫（${inventory.quantity}）を超える減少調整はできません`);
      return;
    }

    const adjustedQty = adjustType === 'increase' ? qty : -qty;

    // 調整処理を実行
    adjust(
      inventory.id,
      adjustedQty,
      reasonCode,
      note || '',
      user?.name || '在庫担当'
    );

    handleClose();
  };

  const qty = parseInt(quantity, 10) || 0;
  const adjustedQty = adjustType === 'increase' ? qty : -qty;
  const newQuantity = inventory.quantity + adjustedQty;
  const isInvalid = adjustType === 'decrease' && qty > inventory.quantity;

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <SwapVert color="primary" />
          在庫調整
        </Box>
      </DialogTitle>
      <DialogContent>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <Box sx={{ bgcolor: 'grey.50', p: 2, borderRadius: 2, mb: 3 }}>
          <Typography variant="body2" color="text.secondary">対象商品</Typography>
          <Typography fontWeight="bold">{inventory.productName}</Typography>
          <Typography variant="body2" color="text.secondary">{inventory.sku}</Typography>
          <Typography variant="body2" sx={{ mt: 1 }}>
            現在庫: <strong>{inventory.quantity}</strong>
          </Typography>
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          調整タイプ
        </Typography>
        <ToggleButtonGroup
          value={adjustType}
          exclusive
          onChange={(_, value) => value && setAdjustType(value)}
          fullWidth
          sx={{ mb: 2 }}
        >
          <ToggleButton value="increase" color="success">
            <Add sx={{ mr: 1 }} />
            増加
          </ToggleButton>
          <ToggleButton value="decrease" color="error">
            <Remove sx={{ mr: 1 }} />
            減少
          </ToggleButton>
        </ToggleButtonGroup>

        <TextField
          fullWidth
          label="調整数量"
          type="number"
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
          inputProps={{ min: 1 }}
          required
          error={isInvalid}
          helperText={isInvalid ? '現在庫を超える減少はできません' : ''}
          sx={{ mb: 2 }}
        />

        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel>調整理由</InputLabel>
          <Select
            value={reasonCode}
            label="調整理由"
            onChange={(e) => setReasonCode(e.target.value)}
          >
            {adjustmentReasons.map((r) => (
              <MenuItem key={r.value} value={r.value}>{r.label}</MenuItem>
            ))}
          </Select>
        </FormControl>

        <TextField
          fullWidth
          label={reasonCode === 'other' ? '備考（必須）' : '備考（任意）'}
          value={note}
          onChange={(e) => setNote(e.target.value)}
          multiline
          rows={2}
          required={reasonCode === 'other'}
          sx={{ mb: 2 }}
        />

        <Divider sx={{ my: 2 }} />

        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography color="text.secondary">現在庫数</Typography>
          <Typography fontWeight="medium">{inventory.quantity}</Typography>
        </Box>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
          <Typography color="text.secondary">調整数</Typography>
          <Typography
            fontWeight="medium"
            color={adjustType === 'increase' ? 'success.main' : 'error.main'}
          >
            {adjustType === 'increase' ? '+' : '-'}{qty || 0}
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
          <Typography color="text.secondary">調整後</Typography>
          <Typography
            variant="h6"
            fontWeight="bold"
            color={isInvalid ? 'error.main' : 'primary.main'}
          >
            {newQuantity}
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} sx={{ ...buttonStyle, color: 'text.primary' }}>キャンセル</Button>
        <Button
          variant="contained"
          onClick={handleSubmit}
          disabled={!quantity || qty <= 0 || isInvalid}
          sx={{
            ...buttonStyle,
            bgcolor: adjustType === 'increase' ? 'success.main' : 'error.main',
            color: adjustType === 'increase' ? 'success.contrastText' : 'error.contrastText',
            '&:hover': {
              boxShadow: 4,
              bgcolor: adjustType === 'increase' ? 'success.dark' : 'error.dark',
            },
          }}
        >
          調整実行
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default AdjustmentModal;
