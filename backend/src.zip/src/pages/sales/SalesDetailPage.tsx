import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  Button,
  Grid,
  Chip,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Stepper,
  Step,
  StepLabel,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
} from '@mui/material';
import {
  ArrowBack,
  Print,
  LocalShipping,
  Cancel,
  CheckCircle,
  Receipt,
} from '@mui/icons-material';
import useSalesStore from '../../store/salesStore';

type SOStatus = 'draft' | 'confirmed' | 'reserved' | 'picked' | 'shipped' | 'delivered' | 'cancelled';

const buttonStyle = {
  transition: 'all 0.3s ease',
  '&:hover': { transform: 'translateY(-2px)', boxShadow: 4 },
  minWidth: 120,
};

const SalesDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const order = useSalesStore((state) => state.getById(id || ''));
  const updateStatus = useSalesStore((state) => state.updateStatus);
  const shipOrder = useSalesStore((state) => state.shipOrder);
  const deliverOrder = useSalesStore((state) => state.deliverOrder);
  const cancelOrder = useSalesStore((state) => state.cancelOrder);

  const [shipOpen, setShipOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [trackingNumber, setTrackingNumber] = useState('');
  const [cancelReason, setCancelReason] = useState('');

  if (!order) {
    return (
      <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
        <Typography>受注情報が見つかりません</Typography>
        <Button onClick={() => navigate('/sales')} sx={buttonStyle}>一覧に戻る</Button>
      </Box>
    );
  }

  const steps = ['受注確定', '引当済', 'ピッキング', '出荷', '納品完了'];
  const getActiveStep = (status: SOStatus) => {
    switch (status) {
      case 'draft': return -1;
      case 'confirmed': return 0;
      case 'reserved': return 1;
      case 'picked': return 2;
      case 'shipped': return 3;
      case 'delivered': return 5;
      case 'cancelled': return -1;
      default: return 0;
    }
  };

  const getStatusChip = (status: SOStatus) => {
    const chipStyle = { minWidth: 100 };
    const statusConfig: Record<SOStatus, { label: string; color: 'default' | 'primary' | 'warning' | 'success' | 'error' | 'info' }> = {
      draft: { label: '下書き', color: 'default' },
      confirmed: { label: '受注確定', color: 'primary' },
      reserved: { label: '引当済', color: 'info' },
      picked: { label: 'ピッキング済', color: 'warning' },
      shipped: { label: '出荷済', color: 'success' },
      delivered: { label: '納品完了', color: 'success' },
      cancelled: { label: 'キャンセル', color: 'error' },
    };
    const config = statusConfig[status];
    return <Chip label={config.label} color={config.color} sx={chipStyle} />;
  };

  const handlePicking = () => {
    updateStatus(order.id, 'picked');
  };

  const handleShip = () => {
    shipOrder(order.id, trackingNumber);
    setShipOpen(false);
    setTrackingNumber('');
  };

  const handleDeliver = () => {
    deliverOrder(order.id);
  };

  const handleCancel = () => {
    if (!cancelReason.trim()) return;
    cancelOrder(order.id, cancelReason);
    setCancelOpen(false);
    setCancelReason('');
  };

  const printDocument = (type: 'delivery' | 'invoice') => {
    const title = type === 'delivery' ? '納品書' : '請求書';
    const printContent = `
      <html>
        <head>
          <title>${title}</title>
          <style>
            body { font-family: sans-serif; padding: 20px; }
            h1 { text-align: center; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background: #f5f5f5; }
            .total { text-align: right; font-weight: bold; margin-top: 20px; }
          </style>
        </head>
        <body>
          <h1>${title}</h1>
          <p>受注番号: ${order.soNumber}</p>
          <p>顧客名: ${order.customerName}</p>
          <p>発行日: ${new Date().toLocaleDateString('ja-JP')}</p>
          <table>
            <tr><th>商品名</th><th>数量</th><th>単価</th><th>小計</th></tr>
            ${order.items.map(item => `
              <tr>
                <td>${item.productName}</td>
                <td>${item.quantity}</td>
                <td>¥${item.unitPrice.toLocaleString()}</td>
                <td>¥${item.subtotal.toLocaleString()}</td>
              </tr>
            `).join('')}
          </table>
          <div class="total">
            <p>小計: ¥${order.totalAmount.toLocaleString()}</p>
            <p>消費税: ¥${order.taxAmount.toLocaleString()}</p>
            <p>合計: ¥${order.grandTotal.toLocaleString()}</p>
          </div>
        </body>
      </html>
    `;
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const canPick = order.status === 'reserved';
  const canShip = order.status === 'picked';
  const canDeliver = order.status === 'shipped';
  const canCancel = !['delivered', 'cancelled'].includes(order.status);

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {/* ヘッダー */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, gap: 2 }}>
        <IconButton 
          onClick={() => navigate('/sales')}
          sx={{ transition: 'all 0.3s ease', '&:hover': { transform: 'translateX(-2px)' } }}
        >
          <ArrowBack />
        </IconButton>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" fontWeight="bold">
            {order.soNumber}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {order.customerName}
          </Typography>
        </Box>
        {getStatusChip(order.status as SOStatus)}
      </Box>

      {/* ステッパー */}
      {order.status !== 'cancelled' && order.status !== 'draft' && (
        <Paper sx={{ p: 3, mb: 3 }}>
          <Stepper activeStep={getActiveStep(order.status as SOStatus)} alternativeLabel>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
        </Paper>
      )}

      {/* アクションボタン - サイズ統一 */}
      <Box sx={{ display: 'flex', gap: 2, mb: 3, flexWrap: 'wrap' }}>
        <Button variant="outlined" startIcon={<Receipt />} onClick={() => printDocument('delivery')} sx={buttonStyle}>
          納品書
        </Button>
        <Button variant="outlined" startIcon={<Print />} onClick={() => printDocument('invoice')} sx={buttonStyle}>
          請求書
        </Button>
        {canPick && (
          <Button variant="contained" startIcon={<CheckCircle />} onClick={handlePicking} color="info" sx={buttonStyle}>
            ピッキング完了
          </Button>
        )}
        {canShip && (
          <Button variant="contained" startIcon={<LocalShipping />} onClick={() => setShipOpen(true)} color="success" sx={buttonStyle}>
            出荷登録
          </Button>
        )}
        {canDeliver && (
          <Button variant="contained" startIcon={<CheckCircle />} onClick={handleDeliver} color="success" sx={buttonStyle}>
            納品完了
          </Button>
        )}
        {canCancel && (
          <Button variant="outlined" startIcon={<Cancel />} onClick={() => setCancelOpen(true)} color="error" sx={buttonStyle}>
            キャンセル
          </Button>
        )}
      </Box>

      <Grid container spacing={3}>
        {/* 受注情報 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              受注情報
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">受注日</Typography>
                <Typography fontWeight="medium">{order.orderDate}</Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography color="text.secondary" variant="body2">納期</Typography>
                <Typography fontWeight="medium">{order.deliveryDate}</Typography>
              </Grid>
              <Grid item xs={12}>
                <Typography color="text.secondary" variant="body2">配送先</Typography>
                <Typography fontWeight="medium">{order.shippingAddress}</Typography>
              </Grid>
              {order.trackingNumber && (
                <Grid item xs={12}>
                  <Typography color="text.secondary" variant="body2">追跡番号</Typography>
                  <Typography fontWeight="medium">{order.trackingNumber}</Typography>
                </Grid>
              )}
            </Grid>
          </Paper>
        </Grid>

        {/* 金額 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              金額
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography>小計</Typography>
              <Typography>¥{order.totalAmount.toLocaleString()}</Typography>
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography>消費税（10%）</Typography>
              <Typography>¥{order.taxAmount.toLocaleString()}</Typography>
            </Box>
            <Divider sx={{ my: 1 }} />
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="h6" fontWeight="bold">合計</Typography>
              <Typography variant="h6" fontWeight="bold" color="primary">
                ¥{order.grandTotal.toLocaleString()}
              </Typography>
            </Box>
          </Paper>
        </Grid>

        {/* 明細 */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              受注明細
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ bgcolor: 'grey.100' }}>
                    <TableCell>SKU</TableCell>
                    <TableCell>商品名</TableCell>
                    <TableCell align="right">単価</TableCell>
                    <TableCell align="right">数量</TableCell>
                    <TableCell align="right">小計</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {order.items.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.sku}</TableCell>
                      <TableCell>{item.productName}</TableCell>
                      <TableCell align="right">¥{item.unitPrice.toLocaleString()}</TableCell>
                      <TableCell align="right">{item.quantity}</TableCell>
                      <TableCell align="right">¥{item.subtotal.toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>

      {/* 出荷登録ダイアログ */}
      <Dialog open={shipOpen} onClose={() => setShipOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>出荷登録</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="追跡番号（任意）"
            value={trackingNumber}
            onChange={(e) => setTrackingNumber(e.target.value)}
            sx={{ mt: 1 }}
            placeholder="例: TRACK-001"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShipOpen(false)} sx={buttonStyle}>キャンセル</Button>
          <Button variant="contained" onClick={handleShip} color="success" sx={buttonStyle}>
            出荷登録
          </Button>
        </DialogActions>
      </Dialog>

      {/* キャンセルダイアログ */}
      <Dialog open={cancelOpen} onClose={() => setCancelOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>受注キャンセル</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="キャンセル理由"
            value={cancelReason}
            onChange={(e) => setCancelReason(e.target.value)}
            multiline
            rows={3}
            required
            sx={{ mt: 1 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelOpen(false)} sx={buttonStyle}>戻る</Button>
          <Button
            variant="contained"
            onClick={handleCancel}
            color="error"
            disabled={!cancelReason.trim()}
            sx={buttonStyle}
          >
            キャンセル実行
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SalesDetailPage;
