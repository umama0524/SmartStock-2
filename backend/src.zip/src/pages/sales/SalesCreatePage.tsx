import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Autocomplete,
  Alert,
  Chip,
} from '@mui/material';
import { ArrowBack, Add, Delete, Save, CheckCircle, Warning, Error as ErrorIcon } from '@mui/icons-material';
import useSalesStore from '../../store/salesStore';
import useInventoryStore from '../../store/inventoryStore';
import { useAuthStore } from '../../store/authStore';

const buttonStyle = {
  transition: 'box-shadow 0.2s ease',
  minWidth: 120,
  '&:hover': { boxShadow: 4 },
};

const mockCustomers = [
  { id: '1', name: '株式会社ABCコーポレーション', address: '〒100-0001 東京都千代田区千代田1-1-1 ABCビル5F' },
  { id: '2', name: '有限会社XYZ商事', address: '〒105-0001 東京都港区虎ノ門2-2-2 XYZビル3F' },
  { id: '3', name: '株式会社DEFエンタープライズ', address: '〒150-0043 東京都渋谷区道玄坂3-3-3 DEFタワー10F' },
];

interface OrderItem {
  id: string;
  productId: string;
  sku: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  availableStock: number;
  location: string;
}

const SalesCreatePage = () => {
  const navigate = useNavigate();
  const addOrder = useSalesStore((state) => state.addOrder);
  const inventory = useInventoryStore((state) => state.inventory);
  const user = useAuthStore((state) => state.user);

  const [customer, setCustomer] = useState<typeof mockCustomers[0] | null>(null);
  const [deliveryDate, setDeliveryDate] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [note, setNote] = useState('');
  const [items, setItems] = useState<OrderItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<typeof inventory[0] | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const products = inventory.map((inv) => ({
    ...inv,
    label: `${inv.sku} - ${inv.productName}`,
  }));

  const addItem = () => {
    if (!selectedProduct) return;

    const existingItem = items.find((item) => item.productId === selectedProduct.id);
    if (existingItem) {
      setItems(
        items.map((item) =>
          item.productId === selectedProduct.id
            ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.unitPrice }
            : item
        )
      );
    } else {
      setItems([
        ...items,
        {
          id: `item-${Date.now()}`,
          productId: selectedProduct.id,
          sku: selectedProduct.sku,
          productName: selectedProduct.productName,
          quantity: 1,
          unitPrice: selectedProduct.unitPrice,
          subtotal: selectedProduct.unitPrice,
          availableStock: selectedProduct.availableQuantity,
          location: selectedProduct.location,
        },
      ]);
    }
    setSelectedProduct(null);
  };

  const updateItemQuantity = (id: string, quantity: number) => {
    if (quantity < 1) return;
    setItems(
      items.map((item) =>
        item.id === id ? { ...item, quantity, subtotal: quantity * item.unitPrice } : item
      )
    );
  };

  const removeItem = (id: string) => {
    setItems(items.filter((item) => item.id !== id));
  };

  const getStockStatus = (item: OrderItem) => {
    if (item.quantity > item.availableStock) {
      return { icon: <ErrorIcon />, color: 'error' as const, label: '在庫不足' };
    }
    if (item.quantity > item.availableStock * 0.8) {
      return { icon: <Warning />, color: 'warning' as const, label: '残りわずか' };
    }
    return { icon: <CheckCircle />, color: 'success' as const, label: '在庫OK' };
  };

  const hasStockError = items.some((item) => item.quantity > item.availableStock);

  const totalAmount = items.reduce((sum, item) => sum + item.subtotal, 0);
  const taxAmount = Math.floor(totalAmount * 0.1);
  const grandTotal = totalAmount + taxAmount;

  const handleSave = (isDraft: boolean) => {
    setError('');

    if (!customer) {
      setError('顧客を選択してください');
      return;
    }
    if (!deliveryDate) {
      setError('納期を入力してください');
      return;
    }
    if (items.length === 0) {
      setError('商品を追加してください');
      return;
    }
    if (!isDraft && hasStockError) {
      setError('在庫不足の商品があります');
      return;
    }

    addOrder({
      customerId: customer.id,
      customerName: customer.name,
      orderDate: new Date().toISOString().split('T')[0],
      deliveryDate,
      status: isDraft ? 'draft' : 'confirmed',
      shippingAddress: shippingAddress || customer.address,
      totalAmount,
      taxAmount,
      grandTotal,
      note,
      items: items.map((item) => ({
        id: item.id,
        productId: item.productId,
        sku: item.sku,
        productName: item.productName,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        subtotal: item.subtotal,
        location: item.location,
      })),
      salesRepId: user?.id || '0',
      salesRepName: user?.name || '不明',
    });

    setSuccess(isDraft ? '下書き保存しました' : '受注確定しました');
    setTimeout(() => navigate('/sales'), 1500);
  };

  return (
    <Box sx={{ maxWidth: 1400, mx: 'auto' }}>
      {/* ヘッダー */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, gap: 2 }}>
        <IconButton 
          onClick={() => navigate('/sales')}
          sx={{ transition: 'all 0.3s ease', '&:hover': { transform: 'translateX(-2px)' } }}
        >
          <ArrowBack />
        </IconButton>
        <Typography variant="h5" fontWeight="bold">
          新規受注登録
        </Typography>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}

      <Grid container spacing={3}>
        {/* 受注情報 */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              受注情報
            </Typography>
            <Divider sx={{ mb: 2 }} />

            <Autocomplete
              options={mockCustomers}
              getOptionLabel={(option) => option.name}
              value={customer}
              onChange={(_, value) => {
                setCustomer(value);
                if (value) setShippingAddress(value.address);
              }}
              renderInput={(params) => (
                <TextField {...params} label="顧客" required sx={{ mb: 2 }} />
              )}
            />

            <TextField
              fullWidth
              label="納期"
              type="date"
              value={deliveryDate}
              onChange={(e) => setDeliveryDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              required
              sx={{ mb: 2 }}
            />

            <TextField
              fullWidth
              label="配送先住所"
              value={shippingAddress}
              onChange={(e) => setShippingAddress(e.target.value)}
              multiline
              rows={2}
              sx={{ mb: 2 }}
            />

            <TextField
              fullWidth
              label="備考"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              multiline
              rows={2}
            />
          </Paper>
        </Grid>

        {/* 金額サマリー */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, height: '100%' }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              金額
            </Typography>
            <Divider sx={{ mb: 2 }} />

            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography>小計</Typography>
              <Typography>¥{totalAmount.toLocaleString()}</Typography>
            </Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
              <Typography>消費税（10%）</Typography>
              <Typography>¥{taxAmount.toLocaleString()}</Typography>
            </Box>
            <Divider sx={{ my: 1 }} />
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography variant="h6" fontWeight="bold">合計</Typography>
              <Typography variant="h6" fontWeight="bold" color="primary">
                ¥{grandTotal.toLocaleString()}
              </Typography>
            </Box>
          </Paper>
        </Grid>

        {/* 商品追加 */}
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight="bold" gutterBottom>
              商品
            </Typography>
            <Divider sx={{ mb: 2 }} />

            <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
              <Autocomplete
                options={products}
                getOptionLabel={(option) => option.label}
                value={selectedProduct}
                onChange={(_, value) => setSelectedProduct(value)}
                renderInput={(params) => (
                  <TextField {...params} label="商品を検索" size="small" />
                )}
                sx={{ flex: 1 }}
              />
              <Button
                variant="contained"
                startIcon={<Add />}
                onClick={addItem}
                disabled={!selectedProduct}
                sx={buttonStyle}
              >
                追加
              </Button>
            </Box>

            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ bgcolor: 'grey.100' }}>
                    <TableCell>SKU</TableCell>
                    <TableCell>商品名</TableCell>
                    <TableCell align="right">単価</TableCell>
                    <TableCell align="center" width={120}>数量</TableCell>
                    <TableCell align="center" sx={{ minWidth: 130 }}>在庫状況</TableCell>
                    <TableCell align="right">小計</TableCell>
                    <TableCell width={50}></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {items.length > 0 ? (
                    items.map((item) => {
                      const stockStatus = getStockStatus(item);
                      return (
                        <TableRow key={item.id}>
                          <TableCell>{item.sku}</TableCell>
                          <TableCell>{item.productName}</TableCell>
                          <TableCell align="right">¥{item.unitPrice.toLocaleString()}</TableCell>
                          <TableCell align="center">
                            <TextField
                              type="number"
                              size="small"
                              value={item.quantity}
                              onChange={(e) =>
                                updateItemQuantity(item.id, parseInt(e.target.value, 10) || 1)
                              }
                              inputProps={{ min: 1, style: { textAlign: 'center' } }}
                              sx={{ width: 80 }}
                            />
                          </TableCell>
                          <TableCell align="center">
                            <Chip
                              icon={stockStatus.icon}
                              label={`${stockStatus.label}(${item.availableStock})`}
                              color={stockStatus.color}
                              size="small"
                              sx={{ minWidth: 120 }}
                            />
                          </TableCell>
                          <TableCell align="right">¥{item.subtotal.toLocaleString()}</TableCell>
                          <TableCell>
                            <IconButton 
                              size="small" 
                              onClick={() => removeItem(item.id)}
                              sx={{ transition: 'all 0.3s ease', '&:hover': { color: 'error.main' } }}
                            >
                              <Delete fontSize="small" />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} align="center">
                        <Typography color="text.secondary">商品を追加してください</Typography>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>

      {/* アクションボタン */}
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2, mt: 3 }}>
        <Button variant="outlined" onClick={() => navigate('/sales')} sx={buttonStyle}>
          キャンセル
        </Button>
        <Button variant="outlined" startIcon={<Save />} onClick={() => handleSave(true)} sx={buttonStyle}>
          下書き保存
        </Button>
        <Button
          variant="contained"
          startIcon={<CheckCircle />}
          onClick={() => handleSave(false)}
          disabled={hasStockError}
          sx={{
            ...buttonStyle,
            bgcolor: 'primary.main',
            color: 'primary.contrastText',
            '&:hover': {
              boxShadow: 4,
              bgcolor: 'primary.dark',
            },
          }}
        >
          受注確定
        </Button>
      </Box>
    </Box>
  );
};

export default SalesCreatePage;
