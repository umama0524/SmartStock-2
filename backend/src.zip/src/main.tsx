import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { ThemeProvider, CssBaseline } from '@mui/material';
import theme from './theme';
import './index.css';
import App from './App.tsx';

// Render the application with the custom theme and CSS baseline.
// The ThemeProvider makes the palette and component overrides available
// throughout the app. CssBaseline provides a consistent reset across
// browsers and sets sensible default typography and margins.
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <App />
    </ThemeProvider>
  </StrictMode>,
);
