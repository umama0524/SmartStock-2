import axios from 'axios';

// APIベースURL
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080/api';

// axiosインスタンス作成
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10秒
});

// リクエストインターセプター
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// レスポンスインターセプター
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // 401エラー（認証失敗）の場合、ログアウト
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('auth-storage');
      window.location.href = '/login';
    }
    
    // エラーメッセージを整形
    const message = error.response?.data?.message || error.message || 'エラーが発生しました';
    console.error('API Error:', message);
    
    return Promise.reject(error);
  }
);

export default api;