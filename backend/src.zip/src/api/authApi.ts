import api from './axios';

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  user: {
    id: number;
    username: string;
    name: string;
    email: string;
    role: string;
  };
}

export const authApi = {
  // ログイン
  login: async (data: LoginRequest): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>('/auth/login', data);
    return response.data;
  },

  // ログアウト
  logout: async (): Promise<void> => {
    await api.post('/auth/logout');
  },
};

export default authApi;