import api from './axios';

export interface InventoryDto {
  id: number;
  sku: string;
  productName: string;
  quantity: number;
  reservedQuantity: number;
  availableQuantity: number;
  reorderPoint: number;
  safetyStock: number;
  status: 'normal' | 'low' | 'critical' | 'excess';
  location: string;
  unitPrice: number;
  lastUpdated: string;
}

export interface InboundRequest {
  quantity: number;
  lotNumber?: string;
  note?: string;
}

export interface OutboundRequest {
  quantity: number;
  reason: string;
  note?: string;
}

export interface AdjustmentRequest {
  adjustmentQuantity: number;
  reasonCode: string;
  note?: string;
}

export const inventoryApi = {
  // 在庫一覧取得
  getAll: async (params?: { search?: string; status?: string }): Promise<InventoryDto[]> => {
    const response = await api.get<InventoryDto[]>('/inventory', { params });
    return response.data;
  },

  // 在庫詳細取得
  getById: async (id: number): Promise<InventoryDto> => {
    const response = await api.get<InventoryDto>(`/inventory/${id}`);
    return response.data;
  },

  // 入庫登録
  inbound: async (id: number, data: InboundRequest): Promise<InventoryDto> => {
    const response = await api.post<InventoryDto>(`/inventory/${id}/inbound`, data);
    return response.data;
  },

  // 出庫登録
  outbound: async (id: number, data: OutboundRequest): Promise<InventoryDto> => {
    const response = await api.post<InventoryDto>(`/inventory/${id}/outbound`, data);
    return response.data;
  },

  // 在庫調整
  adjust: async (id: number, data: AdjustmentRequest): Promise<InventoryDto> => {
    const response = await api.post<InventoryDto>(`/inventory/${id}/adjust`, data);
    return response.data;
  },
};

export default inventoryApi;