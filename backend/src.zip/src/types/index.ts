// ユーザー関連
export interface User {
  id: string;
  username: string;
  email: string;
  role: UserRole;
  name: string;
  avatar?: string;
  createdAt: string;
}

export type UserRole = 
  | 'viewer'
  | 'inventory'
  | 'purchase'
  | 'sales'
  | 'approver'
  | 'admin';

// 認証関連
export interface LoginCredentials {
  username: string;
  password: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => void;
}

// 在庫関連
export interface Inventory {
  id: string;
  sku: string;
  productName: string;
  quantity: number;
  reservedQuantity: number;
  availableQuantity: number;
  reorderPoint: number;
  safetyStock: number;
  status: InventoryStatus;
  location: string;
  lastUpdated: string;
}

export type InventoryStatus = 'normal' | 'low' | 'critical' | 'excess';

// ダッシュボード関連
export interface DashboardStats {
  inventory: {
    total: number;
    critical: number;
    low: number;
  };
  purchases: {
    pending: number;
    dueToday: number;
  };
  sales: {
    pending: number;
    shipToday: number;
  };
}

// 在庫取引関連
export type TransactionType = '入庫' | '出庫' | '調整' | '棚卸';

export interface InventoryTransaction {
  id: number;
  date: string;
  type: TransactionType;
  quantity: number;
  balance: number;
  reason: string;
  user: string;
  lotNumber?: string;
  note?: string;
}

// 入庫登録フォーム
export interface InboundFormData {
  quantity: number;
  lotNumber: string;
  date: string;
  note: string;
}

// 出庫登録フォーム
export interface OutboundFormData {
  quantity: number;
  date: string;
  reason: string;
  note: string;
}

// 在庫調整フォーム
export interface AdjustmentFormData {
  adjustmentQuantity: number;
  reasonCode: AdjustmentReasonCode;
  note: string;
}

export type AdjustmentReasonCode = 
  | 'damaged'      // 破損
  | 'expired'      // 期限切れ
  | 'lost'         // 紛失
  | 'found'        // 発見
  | 'count_diff'   // 棚卸差異
  | 'other';       // その他

// 発注関連
export type POStatus = 'draft' | 'pending' | 'approved' | 'partial' | 'completed' | 'cancelled';

export interface Supplier {
  id: string;
  name: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  address?: string;
}

export interface Product {
  id: string;
  sku: string;
  productName: string;
  unitPrice: number;
  category?: string;
}

export interface PurchaseOrderItem {
  id: string;
  productId: string;
  sku: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export interface PurchaseOrderFormData {
  supplierId: string;
  supplierName: string;
  expectedDeliveryDate: string;
  paymentTerms: string;
  note: string;
  items: PurchaseOrderItem[];
}

// 販売関連
export type SOStatus = 'draft' | 'confirmed' | 'reserved' | 'picked' | 'shipped' | 'delivered' | 'cancelled';

export interface Customer {
  id: string;
  name: string;
  contactPerson?: string;
  email?: string;
  phone?: string;
  address?: string;
}

export interface SalesOrderItem {
  id: string;
  productId: string;
  sku: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  availableStock?: number;
}

export interface SalesOrderFormData {
  customerId: string;
  customerName: string;
  deliveryDate: string;
  shippingAddress: string;
  note: string;
  items: SalesOrderItem[];
}

// 承認関連（Phase3で追加）
export type ApprovalStatus = 'pending' | 'approved' | 'rejected';
export type ApprovalType = 'purchase' | 'adjustment';

export interface ApprovalRequest {
  id: string;
  type: ApprovalType;
  referenceId: string;
  referenceNumber: string;
  title: string;
  requesterId: string;
  requesterName: string;
  requestDate: string;
  status: ApprovalStatus;
  amount?: number;
  itemCount?: number;
  reason?: string;
  note?: string;
  approverName?: string;
  approvedDate?: string;
  approverComment?: string;
}